import { indexSearchResult } from "./search"

// Mock search results for demonstration
const mockSearchResults = [
  {
    id: "1",
    title: "Getting Started with Web Development",
    url: "https://example.com/web-dev",
    description: "Learn the basics of HTML, CSS, and JavaScript",
    category: "Learning",
  },
  {
    id: "2",
    title: "React Best Practices",
    url: "https://example.com/react",
    description: "Master React patterns and optimization techniques",
    category: "Development",
  },
  {
    id: "3",
    title: "Design Systems Guide",
    url: "https://example.com/design",
    description: "Create scalable and maintainable design systems",
    category: "Design",
  },
  {
    id: "4",
    title: "TypeScript Advanced Types",
    url: "https://example.com/typescript",
    description: "Deep dive into TypeScript's type system",
    category: "Development",
  },
  {
    id: "5",
    title: "Web Performance Optimization",
    url: "https://example.com/performance",
    description: "Techniques to improve your website's speed",
    category: "Performance",
  },
]

export async function performSearch(query: string) {
  try {
    // For now, return mock results filtered by query
    // In production, use Upstash vector search
    const filtered = mockSearchResults.filter(
      (result) =>
        result.title.toLowerCase().includes(query.toLowerCase()) ||
        result.description.toLowerCase().includes(query.toLowerCase()),
    )

    return filtered.length > 0 ? filtered : mockSearchResults.slice(0, 5) // Return top 5 if no matches
  } catch (error) {
    console.error("Error performing search:", error)
    return mockSearchResults.slice(0, 5)
  }
}

export async function indexNewResult(title: string, url: string, description: string, category: string) {
  const id = `result_${Date.now()}`
  await indexSearchResult(id, title, url, description, category)
  return id
}
