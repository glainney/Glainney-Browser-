import { Index } from "@upstash/vector"

// Initialize Upstash Search client
const searchIndex = new Index({
  url: process.env.UPSTASH_SEARCH_REST_URL,
  token: process.env.UPSTASH_SEARCH_REST_TOKEN,
})

export interface SearchResult {
  id: string
  title: string
  url: string
  description: string
  category: string
  score: number
}

export async function indexSearchResult(id: string, title: string, url: string, description: string, category: string) {
  try {
    await searchIndex.upsert({
      id,
      values: [0.1, 0.2, 0.3], // Placeholder embeddings - in production, use real embeddings
      metadata: {
        title,
        url,
        description,
        category,
        timestamp: Date.now(),
      },
    })
  } catch (error) {
    console.error("Error indexing search result:", error)
  }
}

export async function searchResults(query: string): Promise<SearchResult[]> {
  try {
    const results = await searchIndex.query({
      vector: [0.1, 0.2, 0.3], // Placeholder - in production, convert query to embeddings
      topK: 10,
      includeMetadata: true,
    })

    return results.map((result: any) => ({
      id: result.id,
      title: result.metadata?.title || "Untitled",
      url: result.metadata?.url || "",
      description: result.metadata?.description || "",
      category: result.metadata?.category || "General",
      score: result.score,
    }))
  } catch (error) {
    console.error("Error searching results:", error)
    return []
  }
}

export async function deleteSearchIndex(id: string) {
  try {
    await searchIndex.delete(id)
  } catch (error) {
    console.error("Error deleting search index:", error)
  }
}
