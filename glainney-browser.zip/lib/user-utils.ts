// User utility functions for managing user state

export function setUser(userData: any) {
  if (userData) {
    localStorage.setItem("glainney-user", JSON.stringify(userData))
  }
}

export function getUser() {
  const savedUser = localStorage.getItem("glainney-user")
  return savedUser ? JSON.parse(savedUser) : null
}

export function clearUser() {
  localStorage.removeItem("glainney-user")
  localStorage.removeItem("glainney-auth-token")
}

export function getUserToken() {
  return localStorage.getItem("glainney-auth-token")
}
