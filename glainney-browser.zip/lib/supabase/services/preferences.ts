import { createClient } from "@/lib/supabase/client"

export async function updateUserPreferences(preferences: any) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data, error } = await supabase
    .from("user_preferences")
    .update({
      current_mood: preferences.currentMood,
      music_enabled: preferences.musicEnabled,
      font_style: preferences.fontStyle,
      live_wallpaper: preferences.liveWallpaper,
      focus_mode_enabled: preferences.focusModeEnabled,
    })
    .eq("user_id", user.id)

  if (error) console.error("Error updating preferences:", error)
  return data
}

export async function getUserPreferences() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data, error } = await supabase.from("user_preferences").select("*").eq("user_id", user.id).single()

  if (error) console.error("Error fetching preferences:", error)
  return data
}
