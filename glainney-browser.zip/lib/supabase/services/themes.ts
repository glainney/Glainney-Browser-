import { createClient } from "@/lib/supabase/client"

export async function saveTheme(themeName: string, themeData: any) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data, error } = await supabase.from("saved_themes").insert({
    user_id: user.id,
    name: themeName,
    bg_color: themeData.bgColor,
    accent_color: themeData.accentColor,
    secondary_color: themeData.secondaryColor,
    highlight_color: themeData.highlightColor,
    text_color: themeData.textColor,
    bg_image: themeData.bgImage,
    bg_video: themeData.bgVideo,
    search_bar_color: themeData.searchBarColor,
    search_bar_radius: themeData.searchBarRadius,
    search_bar_glow: themeData.searchBarGlow,
  })

  if (error) console.error("Error saving theme:", error)
  return data
}

export async function getSavedThemes() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  const { data, error } = await supabase
    .from("saved_themes")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) console.error("Error fetching themes:", error)
  return data || []
}

export async function deleteTheme(id: string) {
  const supabase = createClient()

  const { error } = await supabase.from("saved_themes").delete().eq("id", id)

  if (error) console.error("Error deleting theme:", error)
}

export async function updateTheme(id: string, themeData: any) {
  const supabase = createClient()

  const { error } = await supabase
    .from("saved_themes")
    .update({
      bg_color: themeData.bgColor,
      accent_color: themeData.accentColor,
      secondary_color: themeData.secondaryColor,
      highlight_color: themeData.highlightColor,
      text_color: themeData.textColor,
      bg_image: themeData.bgImage,
      bg_video: themeData.bgVideo,
      search_bar_color: themeData.searchBarColor,
      search_bar_radius: themeData.searchBarRadius,
      search_bar_glow: themeData.searchBarGlow,
    })
    .eq("id", id)

  if (error) console.error("Error updating theme:", error)
}
