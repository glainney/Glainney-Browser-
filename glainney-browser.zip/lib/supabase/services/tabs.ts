import { createClient } from "@/lib/supabase/client"

export async function saveTabs(tabs: any[]) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  // Delete existing tabs
  await supabase.from("tabs").delete().eq("user_id", user.id)

  // Insert new tabs
  const { data, error } = await supabase.from("tabs").insert(
    tabs.map((tab) => ({
      user_id: user.id,
      title: tab.title,
      url: tab.url,
      category: tab.category || "General",
      is_active: tab.isActive || false,
    })),
  )

  if (error) console.error("Error saving tabs:", error)
  return data
}

export async function getTabs() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  const { data, error } = await supabase
    .from("tabs")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) console.error("Error fetching tabs:", error)
  return data || []
}
