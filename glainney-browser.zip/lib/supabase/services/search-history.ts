import { createClient } from "@/lib/supabase/client"

export async function addSearchHistory(query: string) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data, error } = await supabase.from("search_history").insert({
    user_id: user.id,
    query,
  })

  if (error) console.error("Error adding search history:", error)
  return data
}

export async function getSearchHistory() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  const { data, error } = await supabase
    .from("search_history")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) console.error("Error fetching search history:", error)
  return data || []
}

export async function pinSearchHistory(id: string, isPinned: boolean) {
  const supabase = createClient()

  const { error } = await supabase.from("search_history").update({ is_pinned: isPinned }).eq("id", id)

  if (error) console.error("Error pinning search history:", error)
}

export async function favoriteSearchHistory(id: string, isFavorite: boolean) {
  const supabase = createClient()

  const { error } = await supabase.from("search_history").update({ is_favorite: isFavorite }).eq("id", id)

  if (error) console.error("Error favoriting search history:", error)
}

export async function deleteSearchHistory(id: string) {
  const supabase = createClient()

  const { error } = await supabase.from("search_history").delete().eq("id", id)

  if (error) console.error("Error deleting search history:", error)
}
