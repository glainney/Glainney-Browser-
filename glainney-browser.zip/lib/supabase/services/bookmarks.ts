import { createClient } from "@/lib/supabase/client"

export async function addBookmark(title: string, url: string, category = "General") {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data, error } = await supabase.from("bookmarks").insert({
    user_id: user.id,
    title,
    url,
    category,
  })

  if (error) console.error("Error adding bookmark:", error)
  return data
}

export async function getBookmarks() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  const { data, error } = await supabase
    .from("bookmarks")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) console.error("Error fetching bookmarks:", error)
  return data || []
}

export async function deleteBookmark(id: string) {
  const supabase = createClient()

  const { error } = await supabase.from("bookmarks").delete().eq("id", id)

  if (error) console.error("Error deleting bookmark:", error)
}
