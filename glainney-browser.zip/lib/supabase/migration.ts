import { createClient } from "@/lib/supabase/client"
import { saveTheme, getSavedThemes } from "./services/themes"
import { updateUserPreferences } from "./services/preferences"

export async function migrateLocalStorageToSupabase() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return

  try {
    // Migrate saved themes
    const savedThemesStr = localStorage.getItem("glainney-themes")
    if (savedThemesStr) {
      const savedThemes = JSON.parse(savedThemesStr)
      for (const theme of savedThemes) {
        const { name, id, ...themeData } = theme
        await saveTheme(name, themeData)
      }
      console.log("[v0] Migrated themes to Supabase")
    }

    // Migrate current theme
    const currentThemeStr = localStorage.getItem("glainney-theme")
    if (currentThemeStr) {
      const currentTheme = JSON.parse(currentThemeStr)
      await saveTheme("Current Theme", currentTheme)
      console.log("[v0] Migrated current theme to Supabase")
    }

    // Migrate user preferences
    const musicEnabled = localStorage.getItem("glainney-music")
    const currentMood = localStorage.getItem("glainney-mood")

    if (musicEnabled || currentMood) {
      await updateUserPreferences({
        musicEnabled: musicEnabled ? JSON.parse(musicEnabled) : false,
        currentMood: currentMood ? JSON.parse(currentMood) : "Calm",
        fontStyle: "Poppins",
        liveWallpaper: "Floating Clouds",
        focusModeEnabled: false,
      })
      console.log("[v0] Migrated preferences to Supabase")
    }

    console.log("[v0] Data migration completed successfully")
  } catch (error) {
    console.error("[v0] Error during migration:", error)
  }
}

export async function syncDataWithSupabase() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return

  try {
    // Fetch all user data from Supabase
    const [themes, preferences] = await Promise.all([getSavedThemes(), getUserPreferences()])

    console.log("[v0] Data synced from Supabase:", { themes, preferences })
    return { themes, preferences }
  } catch (error) {
    console.error("[v0] Error syncing data:", error)
  }
}

async function getUserPreferences() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data } = await supabase.from("user_preferences").select("*").eq("user_id", user.id).single()

  return data
}
