import { createClient } from "@/lib/supabase/client"

export function subscribeToSearchHistory(userId: string, callback: (data: any) => void) {
  const supabase = createClient()

  const subscription = supabase
    .channel(`search_history:${userId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "search_history",
        filter: `user_id=eq.${userId}`,
      },
      (payload) => {
        callback(payload)
      },
    )
    .subscribe()

  return subscription
}

export function subscribeToThemes(userId: string, callback: (data: any) => void) {
  const supabase = createClient()

  const subscription = supabase
    .channel(`saved_themes:${userId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "saved_themes",
        filter: `user_id=eq.${userId}`,
      },
      (payload) => {
        callback(payload)
      },
    )
    .subscribe()

  return subscription
}

export function subscribeToPreferences(userId: string, callback: (data: any) => void) {
  const supabase = createClient()

  const subscription = supabase
    .channel(`user_preferences:${userId}`)
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "user_preferences",
        filter: `user_id=eq.${userId}`,
      },
      (payload) => {
        callback(payload)
      },
    )
    .subscribe()

  return subscription
}
