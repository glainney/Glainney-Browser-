"use client"

import { generateText } from "ai"

export type AIMode = "concise" | "explainer" | "creative" | "source"

export interface AIResponse {
  answer: string
  mode: AIMode
  sources?: Array<{
    title: string
    url: string
    summary: string
  }>
  followUpQuestions?: string[]
}

const systemPrompts = {
  concise: "Provide short, direct answers in 1-2 sentences. Be precise and to the point.",
  explainer: "Provide detailed but simple explanations. Break down complex topics into easy-to-understand parts.",
  creative: "Provide answers in a dreamy, aesthetic, and creative tone. Use poetic language and vivid descriptions.",
  source:
    "Provide answers with detailed source references and summaries from reliable sources like Google and Wikipedia.",
}

export async function generateAIResponse(query: string, mode: AIMode = "concise"): Promise<AIResponse> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: systemPrompts[mode],
      prompt: query,
      temperature: mode === "creative" ? 0.8 : 0.5,
    })

    // Generate follow-up questions
    const followUpQuestions = await generateFollowUpQuestions(query)

    // Mock sources for demonstration
    const sources = mode === "source" ? generateMockSources(query) : undefined

    return {
      answer: text,
      mode,
      sources,
      followUpQuestions,
    }
  } catch (error) {
    console.error("[v0] AI generation error:", error)
    return {
      answer: "I encountered an error processing your request. Please try again.",
      mode,
      followUpQuestions: [],
    }
  }
}

async function generateFollowUpQuestions(query: string): Promise<string[]> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `Generate 3 follow-up questions related to: "${query}". Return only the questions, one per line, without numbering.`,
      temperature: 0.7,
    })

    return text
      .split("\n")
      .filter((q) => q.trim().length > 0)
      .slice(0, 3)
  } catch {
    return []
  }
}

function generateMockSources(query: string) {
  return [
    {
      title: "Wikipedia",
      url: "https://wikipedia.org",
      summary: `Information about ${query} from Wikipedia's comprehensive database.`,
    },
    {
      title: "Google Search",
      url: "https://google.com",
      summary: `Top results for "${query}" from across the web.`,
    },
    {
      title: "Educational Resources",
      url: "https://example.com",
      summary: `Curated educational content related to ${query}.`,
    },
  ]
}
