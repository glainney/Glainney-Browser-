"use client"

import { useState, useEffect, useRef } from "react"
import BrowserHeader from "@/components/browser-header"
import SearchBar from "@/components/search-bar"
import CustomizationPanel from "@/components/customization-panel"
import StickerCanvas from "@/components/sticker-canvas"
import TimeWidget from "@/components/time-widget"
import ParticleEffect from "@/components/particle-effect"
import SearchResults from "@/components/search-results"
import TabManager from "@/components/tab-manager"
import AuthModal from "@/components/auth-modal"
import UserProfile from "@/components/user-profile"
import MoodThemes from "@/components/mood-themes"
import { useAuth } from "@/hooks/use-auth"
import { migrateLocalStorageToSupabase } from "@/lib/supabase/migration"
import { setUser } from "@/lib/user-utils" // Declare or import setUser

export default function Home() {
  const { user, loading: authLoading, logout } = useAuth()
  const [showCustomization, setShowCustomization] = useState(false)
  const [showTabManager, setShowTabManager] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const [showMoodThemes, setShowMoodThemes] = useState(false)
  const [searchQuery, setSearchQuery] = useState<string | null>(null)
  const [currentMood, setCurrentMood] = useState<string | null>(null)
  const [theme, setTheme] = useState({
    bgColor: "#FDFBF8",
    accentColor: "#A8CBB7",
    secondaryColor: "#F8C8DC",
    highlightColor: "#CFE8E0",
    textColor: "#333333",
    bgImage: "",
    bgVideo: "",
    searchBarColor: "#FFFFFF",
    searchBarRadius: "1.2rem",
    searchBarGlow: true,
  })
  const [stickers, setStickers] = useState<any[]>([])
  const [savedThemes, setSavedThemes] = useState<any[]>([])
  const [musicEnabled, setMusicEnabled] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  // Load saved preferences from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem("glainney-theme")
    const savedStickers = localStorage.getItem("glainney-stickers")
    const savedThemesList = localStorage.getItem("glainney-themes")
    const savedMusic = localStorage.getItem("glainney-music")
    const savedUser = localStorage.getItem("glainney-user")
    const savedMood = localStorage.getItem("glainney-mood")

    if (savedTheme) {
      setTheme(JSON.parse(savedTheme))
    }
    if (savedStickers) {
      setStickers(JSON.parse(savedStickers))
    }
    if (savedThemesList) {
      setSavedThemes(JSON.parse(savedThemesList))
    }
    if (savedMusic) {
      setMusicEnabled(JSON.parse(savedMusic))
    }
    if (savedUser) {
      setUser(JSON.parse(savedUser)) // Use setUser here
    }
    if (savedMood) {
      setCurrentMood(JSON.parse(savedMood))
    }
  }, [])

  // Save theme to localStorage
  useEffect(() => {
    localStorage.setItem("glainney-theme", JSON.stringify(theme))
    applyTheme(theme)
  }, [theme])

  // Save stickers to localStorage
  useEffect(() => {
    localStorage.setItem("glainney-stickers", JSON.stringify(stickers))
  }, [stickers])

  // Save music preference
  useEffect(() => {
    localStorage.setItem("glainney-music", JSON.stringify(musicEnabled))
  }, [musicEnabled])

  useEffect(() => {
    if (user && !authLoading) {
      migrateLocalStorageToSupabase().catch((err) => {
        console.error("[v0] Migration error:", err)
      })
    }
  }, [user, authLoading])

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === "k") {
          e.preventDefault()
          const searchInput = document.querySelector('input[placeholder="Search the web..."]') as HTMLInputElement
          searchInput?.focus()
        } else if (e.key === ",") {
          e.preventDefault()
          setShowCustomization(!showCustomization)
        } else if (e.key === "m") {
          e.preventDefault()
          setMusicEnabled(!musicEnabled)
        } else if (e.key === "t") {
          e.preventDefault()
          setShowTabManager(!showTabManager)
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [showCustomization, musicEnabled, showTabManager])

  const applyTheme = (themeData: any) => {
    const root = document.documentElement
    root.style.setProperty("--primary", themeData.accentColor)
    root.style.setProperty("--secondary", themeData.secondaryColor)
    root.style.setProperty("--muted", themeData.highlightColor)
    root.style.setProperty("--foreground", themeData.textColor)
  }

  const handleThemeChange = (newTheme: any) => {
    setTheme(newTheme)
  }

  const handleApplyMood = (moodTheme: any) => {
    setTheme(moodTheme.colors)
    setCurrentMood(moodTheme.id)
    localStorage.setItem("glainney-mood", JSON.stringify(moodTheme.id))
  }

  const handleAddSticker = (sticker: any) => {
    setStickers([...stickers, { ...sticker, id: Date.now() }])
  }

  const handleRemoveSticker = (id: number) => {
    setStickers(stickers.filter((s) => s.id !== id))
  }

  const handleUpdateSticker = (id: number, x: number, y: number) => {
    setStickers(stickers.map((s) => (s.id === id ? { ...s, x, y } : s)))
  }

  const handleSaveTheme = (themeName: string) => {
    const newTheme = { ...theme, name: themeName, id: Date.now() }
    setSavedThemes([...savedThemes, newTheme])
    localStorage.setItem("glainney-themes", JSON.stringify([...savedThemes, newTheme]))
  }

  const handleLoadTheme = (themeId: number) => {
    const loadedTheme = savedThemes.find((t) => t.id === themeId)
    if (loadedTheme) {
      const { name, id, ...themeData } = loadedTheme
      setTheme(themeData)
    }
  }

  const handleResetTheme = () => {
    const defaultTheme = {
      bgColor: "#FDFBF8",
      accentColor: "#A8CBB7",
      secondaryColor: "#F8C8DC",
      highlightColor: "#CFE8E0",
      textColor: "#333333",
      bgImage: "",
      bgVideo: "",
      searchBarColor: "#FFFFFF",
      searchBarRadius: "1.2rem",
      searchBarGlow: true,
    }
    setTheme(defaultTheme)
    setStickers([])
    setCurrentMood(null)
    localStorage.removeItem("glainney-mood")
  }

  const handleSearch = (query: string) => {
    setSearchQuery(query)
  }

  const handleLogout = async () => {
    await logout()
    setShowProfile(false)
  }

  const backgroundStyle: any = {
    backgroundColor: theme.bgColor,
  }

  if (theme.bgImage) {
    backgroundStyle.backgroundImage = `url(${theme.bgImage})`
    backgroundStyle.backgroundSize = "cover"
    backgroundStyle.backgroundPosition = "center"
  }

  if (theme.bgVideo) {
    // Video background will be handled separately
  }

  if (searchQuery) {
    return <SearchResults query={searchQuery} onBack={() => setSearchQuery(null)} theme={theme} />
  }

  return (
    <div ref={containerRef} className="min-h-screen w-full transition-colors duration-500" style={backgroundStyle}>
      {/* Video Background */}
      {theme.bgVideo && (
        <video autoPlay muted loop className="fixed inset-0 w-full h-full object-cover -z-10" src={theme.bgVideo} />
      )}

      {/* Overlay for better text readability */}
      {(theme.bgImage || theme.bgVideo) && <div className="fixed inset-0 bg-black/10 -z-10" />}

      <ParticleEffect />

      <BrowserHeader
        onCustomizeClick={() => setShowCustomization(!showCustomization)}
        musicEnabled={musicEnabled}
        onMusicToggle={() => setMusicEnabled(!musicEnabled)}
        onTabsClick={() => setShowTabManager(!showTabManager)}
        user={user}
        onAuthClick={() => setShowAuthModal(true)}
        onProfileClick={() => setShowProfile(true)}
      />

      <main className="flex flex-col items-center justify-center min-h-[calc(100vh-120px)] px-4 py-8">
        <TimeWidget />

        <SearchBar theme={theme} onSearch={handleSearch} />

        <StickerCanvas
          stickers={stickers}
          onRemoveSticker={handleRemoveSticker}
          onUpdateSticker={handleUpdateSticker}
        />
      </main>

      {showCustomization && (
        <CustomizationPanel
          theme={theme}
          onThemeChange={handleThemeChange}
          onAddSticker={handleAddSticker}
          onSaveTheme={handleSaveTheme}
          onLoadTheme={handleLoadTheme}
          onResetTheme={handleResetTheme}
          savedThemes={savedThemes}
          onClose={() => setShowCustomization(false)}
          onOpenMoodThemes={() => {
            setShowCustomization(false)
            setShowMoodThemes(true)
          }}
        />
      )}

      {showTabManager && (
        <TabManager
          theme={theme}
          onSelectTab={(tab) => {
            setShowTabManager(false)
          }}
          onClose={() => setShowTabManager(false)}
        />
      )}

      {showAuthModal && (
        <AuthModal
          theme={theme}
          onClose={() => setShowAuthModal(false)}
          onAuthSuccess={(userData) => {
            // User state will be updated by useAuth hook
            setShowAuthModal(false)
          }}
        />
      )}

      {showProfile && user && (
        <UserProfile user={user} theme={theme} onLogout={handleLogout} onClose={() => setShowProfile(false)} />
      )}

      {showMoodThemes && (
        <MoodThemes theme={theme} onApplyMood={handleApplyMood} onClose={() => setShowMoodThemes(false)} />
      )}
    </div>
  )
}
