import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

export async function POST(request: Request) {
  try {
    const { query } = await request.json()

    if (!query || query.trim().length === 0) {
      return Response.json({ error: "Query is required" }, { status: 400 })
    }

    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
            } catch {
              // Handle cookie setting errors
            }
          },
        },
      },
    )

    const { data: user } = await supabase.auth.getUser()
    const userId = user?.user?.id || "anonymous"

    await supabase.from("search_history").insert({
      user_id: userId,
      query: query.trim(),
      results_count: 0,
      created_at: new Date().toISOString(),
    })

    const results = generateSearchResults(query)

    return Response.json({
      query,
      results,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("[v0] Search error:", error)
    return Response.json({ error: "Search failed" }, { status: 500 })
  }
}

function generateSearchResults(query: string) {
  const lowerQuery = query.toLowerCase()

  const knowledgeBase: Record<string, any[]> = {
    "what is": [
      {
        title: `What is ${query}?`,
        snippet: `Learn about ${query} - a comprehensive guide to understanding this topic.`,
        category: "Definition",
        source: "Glainney Knowledge Base",
      },
    ],
    "how to": [
      {
        title: `How to ${query}`,
        snippet: `Step-by-step guide on how to ${query}. Follow these simple steps to get started.`,
        category: "Tutorial",
        source: "Glainney Guides",
      },
    ],
    best: [
      {
        title: `Best ${query}`,
        snippet: `Discover the best options for ${query}. Compare features and find what works for you.`,
        category: "Recommendations",
        source: "Glainney Reviews",
      },
    ],
  }

  let results = []

  // Check for specific query patterns
  if (lowerQuery.includes("what is")) {
    results = [
      {
        title: `Understanding ${query.replace(/what is /i, "")}`,
        snippet: `${query.replace(/what is /i, "")} is a concept that refers to... Learn more about its definition, uses, and importance.`,
        category: "Definition",
        source: "Glainney Knowledge Base",
        icon: "📚",
      },
      {
        title: `${query.replace(/what is /i, "")} - Complete Guide`,
        snippet: `A comprehensive guide covering everything you need to know about ${query.replace(/what is /i, "")}.`,
        category: "Guide",
        source: "Glainney Guides",
        icon: "📖",
      },
    ]
  } else if (lowerQuery.includes("how to")) {
    results = [
      {
        title: `Step-by-Step: ${query}`,
        snippet: `Learn how to ${query.replace(/how to /i, "")} with this easy-to-follow guide. Perfect for beginners.`,
        category: "Tutorial",
        source: "Glainney Tutorials",
        icon: "🎓",
      },
      {
        title: `${query.replace(/how to /i, "")} - Tips & Tricks`,
        snippet: `Advanced tips and tricks for ${query.replace(/how to /i, "")}. Improve your skills with expert advice.`,
        category: "Tips",
        source: "Glainney Tips",
        icon: "💡",
      },
    ]
  } else if (lowerQuery.includes("best")) {
    results = [
      {
        title: `Top ${query.replace(/best /i, "")} Recommendations`,
        snippet: `Discover the best options for ${query.replace(/best /i, "")}. Curated recommendations based on quality and popularity.`,
        category: "Recommendations",
        source: "Glainney Reviews",
        icon: "⭐",
      },
      {
        title: `${query.replace(/best /i, "")} Comparison Guide`,
        snippet: `Compare different options for ${query.replace(/best /i, "")} and find the perfect fit for your needs.`,
        category: "Comparison",
        source: "Glainney Guides",
        icon: "📊",
      },
    ]
  } else {
    results = [
      {
        title: `${query} - Overview`,
        snippet: `Explore comprehensive information about ${query}. Discover key facts, uses, and related topics.`,
        category: "Overview",
        source: "Glainney Knowledge Base",
        icon: "🔍",
      },
      {
        title: `${query} - In-Depth Guide`,
        snippet: `A detailed guide covering all aspects of ${query}. Learn from experts and community insights.`,
        category: "Guide",
        source: "Glainney Guides",
        icon: "📚",
      },
      {
        title: `${query} - Community Insights`,
        snippet: `See what others are saying about ${query}. Join the conversation and share your thoughts.`,
        category: "Community",
        source: "Glainney Community",
        icon: "💬",
      },
      {
        title: `${query} - Latest Updates`,
        snippet: `Stay updated with the latest news and developments related to ${query}.`,
        category: "News",
        source: "Glainney News",
        icon: "📰",
      },
    ]
  }

  return results
}
