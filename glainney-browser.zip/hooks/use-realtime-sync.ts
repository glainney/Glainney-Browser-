"use client"

import { useEffect } from "react"
import { subscribeToSearchHistory, subscribeToThemes, subscribeToPreferences } from "@/lib/supabase/realtime"

export function useRealtimeSync(userId: string | undefined, onUpdate: (type: string, data: any) => void) {
  useEffect(() => {
    if (!userId) return

    const subscriptions = [
      subscribeToSearchHistory(userId, (payload) => {
        onUpdate("search_history", payload)
      }),
      subscribeToThemes(userId, (payload) => {
        onUpdate("themes", payload)
      }),
      subscribeToPreferences(userId, (payload) => {
        onUpdate("preferences", payload)
      }),
    ]

    return () => {
      subscriptions.forEach((sub) => {
        sub.unsubscribe()
      })
    }
  }, [userId, onUpdate])
}
