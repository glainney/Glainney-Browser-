"use client"

import { useEffect, useState, useCallback } from "react"
import { createClient } from "@/lib/supabase/client"

export function useAuth() {
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const supabase = createClient()

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        setLoading(true)

        // Check for existing session
        const {
          data: { session },
        } = await supabase.auth.getSession()

        if (session?.user) {
          // Fetch user profile from database
          const { data: profile, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", session.user.id)
            .single()

          if (profileError && profileError.code !== "PGRST116") {
            console.error("[v0] Error fetching profile:", profileError)
            throw profileError
          }

          const userData = {
            id: session.user.id,
            email: session.user.email,
            username: profile?.username || session.user.email?.split("@")[0] || "User",
            createdAt: profile?.created_at || new Date().toISOString(),
          }

          setUser(userData)
          localStorage.setItem("glainney-user", JSON.stringify(userData))
          localStorage.setItem("glainney-auth-token", session.access_token)
        } else {
          // Check localStorage for offline user
          const savedUser = localStorage.getItem("glainney-user")
          if (savedUser) {
            setUser(JSON.parse(savedUser))
          }
        }
      } catch (err) {
        console.error("[v0] Auth initialization error:", err)
        setError(err instanceof Error ? err.message : "Auth initialization failed")
      } finally {
        setLoading(false)
      }
    }

    initializeAuth()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

        const userData = {
          id: session.user.id,
          email: session.user.email,
          username: profile?.username || session.user.email?.split("@")[0] || "User",
          createdAt: profile?.created_at || new Date().toISOString(),
        }

        setUser(userData)
        localStorage.setItem("glainney-user", JSON.stringify(userData))
        localStorage.setItem("glainney-auth-token", session.access_token)
      } else if (event === "SIGNED_OUT") {
        setUser(null)
        localStorage.removeItem("glainney-user")
        localStorage.removeItem("glainney-auth-token")
      }
    })

    return () => {
      subscription?.unsubscribe()
    }
  }, [supabase])

  const logout = useCallback(async () => {
    try {
      await supabase.auth.signOut()
      setUser(null)
      localStorage.removeItem("glainney-user")
      localStorage.removeItem("glainney-auth-token")
    } catch (err) {
      console.error("[v0] Logout error:", err)
      setError(err instanceof Error ? err.message : "Logout failed")
    }
  }, [supabase])

  return { user, loading, error, logout }
}
