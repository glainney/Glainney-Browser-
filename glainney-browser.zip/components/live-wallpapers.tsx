"use client"

import { Cloud, Sparkles, Wind } from "lucide-react"
import { useEffect, useRef } from "react"

interface LiveWallpaperProps {
  type: string
  isActive: boolean
}

export default function LiveWallpaper({ type, isActive }: LiveWallpaperProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!isActive || !canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    let animationId: number

    const drawClouds = () => {
      ctx.fillStyle = "rgba(255, 255, 255, 0.1)"
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      const time = Date.now() * 0.0001
      for (let i = 0; i < 5; i++) {
        const x = (Math.sin(time + i) * canvas.width) / 2 + canvas.width / 4
        const y = (Math.cos(time * 0.5 + i) * canvas.height) / 3 + canvas.height / 4
        ctx.beginPath()
        ctx.arc(x, y, 50 + Math.sin(time + i) * 10, 0, Math.PI * 2)
        ctx.fill()
      }
      animationId = requestAnimationFrame(drawClouds)
    }

    const drawSparkles = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      const time = Date.now() * 0.001
      const particleCount = 50

      for (let i = 0; i < particleCount; i++) {
        const angle = (i / particleCount) * Math.PI * 2 + time
        const distance = 100 + Math.sin(time * 0.5 + i) * 50
        const x = canvas.width / 2 + Math.cos(angle) * distance
        const y = canvas.height / 2 + Math.sin(angle) * distance
        const opacity = Math.sin(time + i) * 0.5 + 0.5

        ctx.fillStyle = `rgba(168, 203, 183, ${opacity * 0.3})`
        ctx.beginPath()
        ctx.arc(x, y, 2, 0, Math.PI * 2)
        ctx.fill()
      }
      animationId = requestAnimationFrame(drawSparkles)
    }

    const drawGradient = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      const time = Date.now() * 0.0005

      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
      const hue1 = (time * 100) % 360
      const hue2 = (time * 100 + 120) % 360

      gradient.addColorStop(0, `hsl(${hue1}, 70%, 80%)`)
      gradient.addColorStop(0.5, `hsl(${hue2}, 70%, 85%)`)
      gradient.addColorStop(1, `hsl(${(hue1 + 240) % 360}, 70%, 80%)`)

      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      animationId = requestAnimationFrame(drawGradient)
    }

    if (type === "clouds") drawClouds()
    else if (type === "sparkles") drawSparkles()
    else if (type === "gradient") drawGradient()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => {
      cancelAnimationFrame(animationId)
      window.removeEventListener("resize", handleResize)
    }
  }, [type, isActive])

  if (!isActive) return null

  return <canvas ref={canvasRef} className="fixed inset-0 -z-10" />
}

interface WallpaperSelectorProps {
  theme: any
  onSelectWallpaper: (type: string) => void
  onClose: () => void
  currentWallpaper: string | null
}

export function WallpaperSelector({ theme, onSelectWallpaper, onClose, currentWallpaper }: WallpaperSelectorProps) {
  const wallpapers = [
    { id: "clouds", name: "Floating Clouds", icon: <Cloud className="w-6 h-6" />, description: "Soft floating clouds" },
    {
      id: "sparkles",
      name: "Sparkles",
      icon: <Sparkles className="w-6 h-6" />,
      description: "Magical sparkle particles",
    },
    { id: "gradient", name: "Gradient Flow", icon: <Wind className="w-6 h-6" />, description: "Animated gradients" },
  ]

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-3xl p-8"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
            Live Wallpapers
          </h2>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {wallpapers.map((wallpaper) => (
            <button
              key={wallpaper.id}
              onClick={() => {
                onSelectWallpaper(wallpaper.id)
                onClose()
              }}
              className="p-6 rounded-2xl transition-smooth hover:scale-105 group relative overflow-hidden"
              style={{
                backgroundColor: theme.highlightColor + "40",
                border:
                  currentWallpaper === wallpaper.id
                    ? `3px solid ${theme.accentColor}`
                    : `2px solid ${theme.accentColor}40`,
              }}
            >
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-smooth"
                style={{ backgroundColor: theme.accentColor }}
              />

              <div className="relative z-10 flex flex-col items-center gap-3">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center group-hover:scale-110 transition-smooth"
                  style={{ backgroundColor: theme.accentColor, color: "#fff" }}
                >
                  {wallpaper.icon}
                </div>

                <h3 className="font-bold text-center" style={{ color: theme.textColor }}>
                  {wallpaper.name}
                </h3>

                <p className="text-xs text-center" style={{ color: theme.textColor + "80" }}>
                  {wallpaper.description}
                </p>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-6 p-4 rounded-xl" style={{ backgroundColor: theme.highlightColor + "40" }}>
          <p className="text-sm" style={{ color: theme.textColor + "80" }}>
            Live wallpapers animate in the background. You can also upload your own static image or video.
          </p>
        </div>
      </div>
    </div>
  )
}
