"use client"

import type React from "react"

import { useState } from "react"
import { X, Plus, Trash2, Download, Upload } from "lucide-react"
import ColorPicker from "./color-picker"
import StickerPicker from "./sticker-picker"

interface CustomizationPanelProps {
  theme: any
  onThemeChange: (theme: any) => void
  onAddSticker: (sticker: any) => void
  onSaveTheme: (name: string) => void
  onLoadTheme: (id: number) => void
  onResetTheme: () => void
  savedThemes: any[]
  onClose: () => void
  onOpenMoodThemes: () => void
}

const PRESET_THEMES = [
  {
    name: "Soft Sage",
    bgColor: "#FDFBF8",
    accentColor: "#A8CBB7",
    secondaryColor: "#F8C8DC",
    highlightColor: "#CFE8E0",
    textColor: "#333333",
  },
  {
    name: "Ocean Breeze",
    bgColor: "#E8F4F8",
    accentColor: "#4A90A4",
    secondaryColor: "#7ECFE4",
    highlightColor: "#B8E0E8",
    textColor: "#1a3a42",
  },
  {
    name: "Sunset Glow",
    bgColor: "#FFF5E6",
    accentColor: "#FF9F43",
    secondaryColor: "#FF6B6B",
    highlightColor: "#FFD93D",
    textColor: "#2d3436",
  },
  {
    name: "Lavender Dream",
    bgColor: "#F5F0FF",
    accentColor: "#B19CD9",
    secondaryColor: "#E6D5FF",
    highlightColor: "#D4B5FF",
    textColor: "#3d2645",
  },
]

export default function CustomizationPanel({
  theme,
  onThemeChange,
  onAddSticker,
  onSaveTheme,
  onLoadTheme,
  onResetTheme,
  savedThemes,
  onClose,
  onOpenMoodThemes,
}: CustomizationPanelProps) {
  const [activeTab, setActiveTab] = useState("colors")
  const [themeName, setThemeName] = useState("")

  const handleColorChange = (key: string, value: string) => {
    onThemeChange({ ...theme, [key]: value })
  }

  const handleBackgroundImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        onThemeChange({ ...theme, bgImage: event.target?.result })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleBackgroundVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        onThemeChange({ ...theme, bgVideo: event.target?.result })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSaveTheme = () => {
    if (themeName.trim()) {
      onSaveTheme(themeName)
      setThemeName("")
    }
  }

  const handleDeleteTheme = (id: number) => {
    const updatedThemes = savedThemes.filter((t) => t.id !== id)
    localStorage.setItem("glainney-themes", JSON.stringify(updatedThemes))
    onClose()
  }

  const handleApplyPreset = (presetTheme: any) => {
    const { name, ...themeData } = presetTheme
    onThemeChange({ ...theme, ...themeData })
  }

  const handleExportTheme = () => {
    const themeData = JSON.stringify(theme, null, 2)
    const element = document.createElement("a")
    element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(themeData))
    element.setAttribute("download", `glainney-theme-${Date.now()}.json`)
    element.style.display = "none"
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const handleImportTheme = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const importedTheme = JSON.parse(event.target?.result as string)
          onThemeChange(importedTheme)
        } catch (error) {
          alert("Invalid theme file")
        }
      }
      reader.readAsText(file)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/30 backdrop-blur-sm animate-slide-in">
      <div className="w-full sm:w-96 max-h-[90vh] bg-background rounded-t-3xl sm:rounded-3xl soft-shadow-lg overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 flex items-center justify-between p-6 border-b border-border bg-background/95 backdrop-blur">
          <h2 className="text-2xl font-bold text-foreground">Customize</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 p-4 border-b border-border overflow-x-auto">
          {["colors", "background", "search", "stickers", "themes", "presets", "moods"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-full font-medium transition-all whitespace-nowrap ${
                activeTab === tab ? "bg-primary text-white" : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Colors Tab */}
          {activeTab === "colors" && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Accent Color</label>
                <ColorPicker value={theme.accentColor} onChange={(value) => handleColorChange("accentColor", value)} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Secondary Color</label>
                <ColorPicker
                  value={theme.secondaryColor}
                  onChange={(value) => handleColorChange("secondaryColor", value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Highlight Color</label>
                <ColorPicker
                  value={theme.highlightColor}
                  onChange={(value) => handleColorChange("highlightColor", value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Background Color</label>
                <ColorPicker value={theme.bgColor} onChange={(value) => handleColorChange("bgColor", value)} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Text Color</label>
                <ColorPicker value={theme.textColor} onChange={(value) => handleColorChange("textColor", value)} />
              </div>
            </div>
          )}

          {/* Background Tab */}
          {activeTab === "background" && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Upload Background Image</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleBackgroundImageUpload}
                  className="w-full px-4 py-2 border border-border rounded-2xl cursor-pointer hover:bg-muted transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Upload Background Video</label>
                <input
                  type="file"
                  accept="video/*"
                  onChange={handleBackgroundVideoUpload}
                  className="w-full px-4 py-2 border border-border rounded-2xl cursor-pointer hover:bg-muted transition-colors"
                />
              </div>
              {(theme.bgImage || theme.bgVideo) && (
                <button
                  onClick={() => onThemeChange({ ...theme, bgImage: "", bgVideo: "" })}
                  className="w-full px-4 py-2 bg-destructive text-white rounded-2xl font-medium hover:opacity-90 transition-opacity"
                >
                  Clear Background
                </button>
              )}
            </div>
          )}

          {/* Search Bar Tab */}
          {activeTab === "search" && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Search Bar Color</label>
                <ColorPicker
                  value={theme.searchBarColor}
                  onChange={(value) => handleColorChange("searchBarColor", value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Border Radius</label>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={Number.parseFloat(theme.searchBarRadius)}
                  onChange={(e) => handleColorChange("searchBarRadius", `${e.target.value}rem`)}
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground mt-1">{theme.searchBarRadius}</p>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={theme.searchBarGlow}
                  onChange={(e) => handleColorChange("searchBarGlow", e.target.checked)}
                  className="w-4 h-4 rounded"
                />
                <span className="text-sm font-medium">Enable Glow Effect</span>
              </label>
            </div>
          )}

          {/* Stickers Tab */}
          {activeTab === "stickers" && <StickerPicker onAddSticker={onAddSticker} />}

          {/* Themes Tab */}
          {activeTab === "themes" && (
            <div className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={themeName}
                  onChange={(e) => setThemeName(e.target.value)}
                  placeholder="Theme name..."
                  className="flex-1 px-4 py-2 border border-border rounded-2xl bg-card text-foreground placeholder-muted-foreground"
                />
                <button
                  onClick={handleSaveTheme}
                  className="px-4 py-2 bg-primary text-white rounded-2xl font-medium hover:opacity-90 transition-opacity"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleExportTheme}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-secondary text-foreground rounded-2xl font-medium hover:opacity-90 transition-opacity"
                >
                  <Download className="w-4 h-4" />
                  Export
                </button>
                <label className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-secondary text-foreground rounded-2xl font-medium hover:opacity-90 transition-opacity cursor-pointer">
                  <Upload className="w-4 h-4" />
                  Import
                  <input type="file" accept=".json" onChange={handleImportTheme} className="hidden" />
                </label>
              </div>

              {savedThemes.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Saved Themes</h3>
                  {savedThemes.map((savedTheme) => (
                    <div key={savedTheme.id} className="flex items-center justify-between p-3 bg-muted rounded-2xl">
                      <button
                        onClick={() => onLoadTheme(savedTheme.id)}
                        className="flex-1 text-left font-medium hover:text-primary transition-colors"
                      >
                        {savedTheme.name}
                      </button>
                      <button
                        onClick={() => handleDeleteTheme(savedTheme.id)}
                        className="p-2 hover:bg-destructive/20 rounded-full transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={onResetTheme}
                className="w-full px-4 py-2 bg-secondary text-foreground rounded-2xl font-medium hover:opacity-90 transition-opacity"
              >
                Reset to Default
              </button>
            </div>
          )}

          {activeTab === "presets" && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Choose from our curated theme presets</p>
              {PRESET_THEMES.map((preset) => (
                <button
                  key={preset.name}
                  onClick={() => handleApplyPreset(preset)}
                  className="w-full p-4 rounded-2xl border-2 border-border hover:border-primary transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex gap-1">
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.accentColor }} />
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.secondaryColor }} />
                      <div className="w-6 h-6 rounded-full" style={{ backgroundColor: preset.highlightColor }} />
                    </div>
                    <span className="font-medium group-hover:text-primary transition-colors">{preset.name}</span>
                  </div>
                </button>
              ))}
            </div>
          )}

          {activeTab === "moods" && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Choose a mood to instantly change your browser's atmosphere, colors, and ambient music
              </p>
              <button
                onClick={onOpenMoodThemes}
                className="w-full px-6 py-4 bg-gradient-to-r from-primary to-secondary text-white rounded-2xl font-semibold hover:shadow-lg hover:scale-105 transition-smooth"
              >
                Explore Mood Themes
              </button>
              <div className="p-4 rounded-xl bg-muted/50">
                <p className="text-xs text-muted-foreground">
                  Available moods: Calm, Romantic, Dreamy, and Focus. Each mood includes curated colors and ambient
                  music.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
