"use client"

import { useState, useEffect } from "react"
import { Search, X, ExternalLink } from "lucide-react"
import { performSearch } from "@/lib/upstash/search-service"

interface AdvancedSearchProps {
  theme: any
  onClose: () => void
}

export default function AdvancedSearch({ theme, onClose }: AdvancedSearchProps) {
  const [query, setQuery] = useState("")
  const [results, setResults] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (query.trim()) {
      const timer = setTimeout(async () => {
        setLoading(true)
        const searchResults = await performSearch(query)
        setResults(searchResults)
        setLoading(false)
      }, 300)

      return () => clearTimeout(timer)
    } else {
      setResults([])
    }
  }, [query])

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-3xl p-6"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
            Advanced Search
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-lg transition-smooth">
            <X className="w-6 h-6" style={{ color: theme.textColor }} />
          </button>
        </div>

        <div className="mb-6">
          <div
            className="flex items-center gap-3 px-4 py-3 rounded-xl"
            style={{ backgroundColor: theme.highlightColor + "40" }}
          >
            <Search className="w-5 h-5" style={{ color: theme.accentColor }} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search the web..."
              className="flex-1 bg-transparent outline-none"
              style={{ color: theme.textColor }}
              autoFocus
            />
          </div>
        </div>

        <div className="space-y-3 max-h-96 overflow-y-auto">
          {loading && (
            <div className="text-center py-8" style={{ color: theme.textColor + "80" }}>
              Searching...
            </div>
          )}

          {!loading && results.length === 0 && query && (
            <div className="text-center py-8" style={{ color: theme.textColor + "80" }}>
              No results found for "{query}"
            </div>
          )}

          {results.map((result) => (
            <a
              key={result.id}
              href={result.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block p-4 rounded-xl transition-smooth hover:scale-102"
              style={{
                backgroundColor: theme.highlightColor + "20",
                borderLeft: `4px solid ${theme.accentColor}`,
              }}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h3 className="font-semibold mb-1" style={{ color: theme.textColor }}>
                    {result.title}
                  </h3>
                  <p className="text-sm mb-2" style={{ color: theme.textColor + "80" }}>
                    {result.description}
                  </p>
                  <div className="flex items-center gap-2">
                    <span
                      className="text-xs px-2 py-1 rounded-full"
                      style={{ backgroundColor: theme.secondaryColor + "40", color: theme.textColor }}
                    >
                      {result.category}
                    </span>
                    <span className="text-xs" style={{ color: theme.textColor + "60" }}>
                      {result.url}
                    </span>
                  </div>
                </div>
                <ExternalLink className="w-5 h-5 flex-shrink-0" style={{ color: theme.accentColor }} />
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  )
}
