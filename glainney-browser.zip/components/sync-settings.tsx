"use client"

import type React from "react"

import { useState } from "react"
import { Cloud, Download, Upload } from "lucide-react"
import { migrateLocalStorageToSupabase } from "@/lib/supabase/migration"

interface SyncSettingsProps {
  theme: any
  user: any
}

export default function SyncSettings({ theme, user }: SyncSettingsProps) {
  const [syncing, setSyncing] = useState(false)
  const [syncStatus, setSyncStatus] = useState("")

  const handleManualSync = async () => {
    setSyncing(true)
    setSyncStatus("Syncing...")

    try {
      await migrateLocalStorageToSupabase()
      setSyncStatus("Sync completed successfully")
      setTimeout(() => setSyncStatus(""), 3000)
    } catch (error) {
      setSyncStatus("Sync failed")
      setTimeout(() => setSyncStatus(""), 3000)
    } finally {
      setSyncing(false)
    }
  }

  const handleExportData = () => {
    const data = {
      theme: localStorage.getItem("glainney-theme"),
      stickers: localStorage.getItem("glainney-stickers"),
      themes: localStorage.getItem("glainney-themes"),
      preferences: localStorage.getItem("glainney-music"),
      mood: localStorage.getItem("glainney-mood"),
    }

    const dataStr = JSON.stringify(data, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = "glainney-backup.json"
    link.click()
  }

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string)
        if (data.theme) localStorage.setItem("glainney-theme", data.theme)
        if (data.stickers) localStorage.setItem("glainney-stickers", data.stickers)
        if (data.themes) localStorage.setItem("glainney-themes", data.themes)
        if (data.preferences) localStorage.setItem("glainney-music", data.preferences)
        if (data.mood) localStorage.setItem("glainney-mood", data.mood)

        setSyncStatus("Data imported successfully")
        setTimeout(() => setSyncStatus(""), 3000)
        window.location.reload()
      } catch (error) {
        setSyncStatus("Import failed")
        setTimeout(() => setSyncStatus(""), 3000)
      }
    }
    reader.readAsText(file)
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold" style={{ color: theme.textColor }}>
        Cloud Sync Settings
      </h3>

      <div className="space-y-3">
        <button
          onClick={handleManualSync}
          disabled={syncing || !user}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth hover:scale-102 disabled:opacity-50"
          style={{ backgroundColor: theme.highlightColor + "40" }}
        >
          <Cloud className="w-5 h-5" style={{ color: theme.accentColor }} />
          <span style={{ color: theme.textColor }}>{syncing ? "Syncing..." : "Sync Now"}</span>
        </button>

        <button
          onClick={handleExportData}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth hover:scale-102"
          style={{ backgroundColor: theme.highlightColor + "40" }}
        >
          <Download className="w-5 h-5" style={{ color: theme.accentColor }} />
          <span style={{ color: theme.textColor }}>Export Backup</span>
        </button>

        <label
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-smooth hover:scale-102 cursor-pointer"
          style={{ backgroundColor: theme.highlightColor + "40" }}
        >
          <Upload className="w-5 h-5" style={{ color: theme.accentColor }} />
          <span style={{ color: theme.textColor }}>Import Backup</span>
          <input type="file" accept=".json" onChange={handleImportData} className="hidden" />
        </label>
      </div>

      {syncStatus && (
        <div
          className="p-3 rounded-xl text-sm"
          style={{
            backgroundColor: syncStatus.includes("failed") ? "#ff6b6b20" : theme.highlightColor + "40",
            color: syncStatus.includes("failed") ? "#ff6b6b" : theme.textColor,
          }}
        >
          {syncStatus}
        </div>
      )}
    </div>
  )
}
