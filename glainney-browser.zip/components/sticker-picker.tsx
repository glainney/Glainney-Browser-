"use client"

const STICKER_OPTIONS = [
  { id: "heart", emoji: "❤️", label: "Heart" },
  { id: "sparkle", emoji: "✨", label: "Sparkle" },
  { id: "star", emoji: "⭐", label: "Star" },
  { id: "flower", emoji: "🌸", label: "Flower" },
  { id: "butterfly", emoji: "🦋", label: "Butterfly" },
  { id: "cloud", emoji: "☁️", label: "Cloud" },
  { id: "moon", emoji: "🌙", label: "Moon" },
  { id: "sun", emoji: "☀️", label: "Sun" },
  { id: "rainbow", emoji: "🌈", label: "Rainbow" },
  { id: "leaf", emoji: "🍃", label: "Leaf" },
  { id: "cherry", emoji: "🍒", label: "Cherry" },
  { id: "bubble", emoji: "🫧", label: "Bubble" },
]

interface StickerPickerProps {
  onAddSticker: (sticker: any) => void
}

export default function StickerPicker({ onAddSticker }: StickerPickerProps) {
  return (
    <div className="grid grid-cols-4 gap-3">
      {STICKER_OPTIONS.map((sticker) => (
        <button
          key={sticker.id}
          onClick={() =>
            onAddSticker({
              id: sticker.id,
              emoji: sticker.emoji,
              x: Math.random() * 80,
              y: Math.random() * 80,
              size: 40,
            })
          }
          className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-muted hover:bg-primary/20 transition-all hover:scale-110 group"
        >
          <span className="text-3xl group-hover:animate-bounce">{sticker.emoji}</span>
          <span className="text-xs font-medium text-center">{sticker.label}</span>
        </button>
      ))}
    </div>
  )
}
