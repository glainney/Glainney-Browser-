"use client"
import { Music, MicOff as MusicOff, Palette, Keyboard, Tags as Tabs, LogIn } from "lucide-react"
import { useState } from "react"

interface BrowserHeaderProps {
  onCustomizeClick: () => void
  musicEnabled: boolean
  onMusicToggle: () => void
  onTabsClick: () => void
  user: any
  onAuthClick: () => void
  onProfileClick: () => void
}

export default function BrowserHeader({
  onCustomizeClick,
  musicEnabled,
  onMusicToggle,
  onTabsClick,
  user,
  onAuthClick,
  onProfileClick,
}: BrowserHeaderProps) {
  const [showShortcuts, setShowShortcuts] = useState(false)

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-lg animate-float">
            G
          </div>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Glainney
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onTabsClick}
            className="p-2 rounded-full hover:bg-muted transition-smooth duration-300 hover:scale-110 group"
            title="View open tabs"
          >
            <Tabs className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
          </button>

          <button
            onClick={onMusicToggle}
            className="p-2 rounded-full hover:bg-muted transition-smooth duration-300 hover:scale-110 group"
            title={musicEnabled ? "Disable music" : "Enable music"}
          >
            {musicEnabled ? (
              <Music className="w-5 h-5 text-primary group-hover:animate-pulse" />
            ) : (
              <MusicOff className="w-5 h-5 text-muted-foreground" />
            )}
          </button>

          <div className="relative">
            <button
              onClick={() => setShowShortcuts(!showShortcuts)}
              className="p-2 rounded-full hover:bg-muted transition-smooth duration-300 hover:scale-110"
              title="Keyboard shortcuts"
            >
              <Keyboard className="w-5 h-5 text-muted-foreground" />
            </button>

            {showShortcuts && (
              <div className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-2xl shadow-lg p-4 animate-fade-in-scale">
                <h3 className="font-bold text-sm mb-3">Keyboard Shortcuts</h3>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span>Focus Search</span>
                    <kbd className="bg-muted px-2 py-1 rounded">Ctrl+K</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>Customize</span>
                    <kbd className="bg-muted px-2 py-1 rounded">Ctrl+,</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>Toggle Music</span>
                    <kbd className="bg-muted px-2 py-1 rounded">Ctrl+M</kbd>
                  </div>
                  <div className="flex justify-between">
                    <span>View Tabs</span>
                    <kbd className="bg-muted px-2 py-1 rounded">Ctrl+T</kbd>
                  </div>
                </div>
              </div>
            )}
          </div>

          {user ? (
            <button
              onClick={onProfileClick}
              className="p-2 rounded-full hover:bg-muted transition-smooth duration-300 hover:scale-110 group"
              title="View profile"
            >
              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xs font-bold">
                {user.username.charAt(0).toUpperCase()}
              </div>
            </button>
          ) : (
            <button
              onClick={onAuthClick}
              className="p-2 rounded-full hover:bg-muted transition-smooth duration-300 hover:scale-110 group"
              title="Sign in"
            >
              <LogIn className="w-5 h-5 text-muted-foreground group-hover:text-primary" />
            </button>
          )}

          <button
            onClick={onCustomizeClick}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary to-secondary text-white font-medium hover:shadow-lg hover:scale-105 transition-smooth duration-300 soft-shadow"
          >
            <Palette className="w-4 h-4" />
            <span className="hidden sm:inline">Customize</span>
          </button>
        </div>
      </div>
    </header>
  )
}
