"use client"

import { ArrowLeft, History, TrendingUp, Share2 } from "lucide-react"
import { useState, useEffect } from "react"
import SearchHistory from "./search-history"
import TrendingSearches from "./trending-searches"

interface SearchResult {
  title: string
  snippet: string
  category: string
  source: string
  icon: string
}

interface SearchResultsProps {
  query: string
  onBack: () => void
  theme: any
}

export default function SearchResults({ query, onBack, theme }: SearchResultsProps) {
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(true)
  const [showHistory, setShowHistory] = useState(false)
  const [showTrending, setShowTrending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchResults = async () => {
      try {
        setLoading(true)
        setError(null)

        const response = await fetch("/api/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query }),
        })

        if (!response.ok) {
          throw new Error("Failed to fetch search results")
        }

        const data = await response.json()
        setResults(data.results)
      } catch (err) {
        console.error("[v0] Search fetch error:", err)
        setError("Failed to load search results. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    const savedHistory = localStorage.getItem("glainney-search-history") || "[]"
    const history = JSON.parse(savedHistory)
    const newItem = {
      id: Date.now().toString(),
      query,
      timestamp: Date.now(),
      pinned: false,
      favorite: false,
    }
    const updated = [newItem, ...history].slice(0, 100)
    localStorage.setItem("glainney-search-history", JSON.stringify(updated))

    fetchResults()
  }, [query])

  const handleShareResult = (result: SearchResult) => {
    const text = `Check out this result from Glainney Browser: ${result.title}`
    if (navigator.share) {
      navigator.share({
        title: "Glainney Browser Result",
        text,
        url: window.location.href,
      })
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(text)
      alert("Result link copied to clipboard!")
    }
  }

  return (
    <div className="w-full min-h-screen transition-colors duration-500" style={{ backgroundColor: theme.bgColor }}>
      {/* Header */}
      <div
        className="sticky top-0 z-40 backdrop-blur-md bg-white/30 border-b"
        style={{ borderColor: theme.accentColor + "20" }}
      >
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 rounded-full hover:bg-white/50 transition-smooth"
            style={{ color: theme.textColor }}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-lg font-semibold" style={{ color: theme.textColor }}>
              Search Results for "{query}"
            </h1>
            <p className="text-sm" style={{ color: theme.textColor + "80" }}>
              {results.length} results found • Powered by Glainney
            </p>
          </div>
          <button
            onClick={() => setShowTrending(true)}
            className="p-2 rounded-full hover:bg-white/50 transition-smooth"
            style={{ color: theme.textColor }}
            title="Trending searches"
          >
            <TrendingUp className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowHistory(true)}
            className="p-2 rounded-full hover:bg-white/50 transition-smooth"
            style={{ color: theme.textColor }}
            title="Search history"
          >
            <History className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Results */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div
              className="animate-spin rounded-full h-12 w-12"
              style={{
                borderColor: theme.accentColor + "20",
                borderTopColor: theme.accentColor,
              }}
            />
          </div>
        ) : error ? (
          <div
            className="p-6 rounded-2xl text-center"
            style={{
              backgroundColor: theme.secondaryColor + "20",
              border: `1px solid ${theme.secondaryColor}40`,
            }}
          >
            <p style={{ color: theme.textColor }}>{error}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {results.map((result, index) => (
              <div
                key={index}
                className="p-4 rounded-2xl transition-smooth hover:scale-102 group cursor-pointer"
                style={{
                  backgroundColor: theme.highlightColor + "40",
                  border: `1px solid ${theme.accentColor}20`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = theme.accentColor + "20"
                  e.currentTarget.style.boxShadow = `0 0 20px ${theme.accentColor}40`
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = theme.highlightColor + "40"
                  e.currentTarget.style.boxShadow = "none"
                }}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xl">{result.icon}</span>
                      <h3
                        className="font-semibold text-base group-hover:underline"
                        style={{ color: theme.accentColor }}
                      >
                        {result.title}
                      </h3>
                    </div>
                    <p className="text-sm mb-2" style={{ color: theme.textColor + "80" }}>
                      {result.snippet}
                    </p>
                    <div className="flex items-center gap-3 text-xs">
                      <span
                        className="px-2 py-1 rounded-full"
                        style={{
                          backgroundColor: theme.accentColor + "20",
                          color: theme.accentColor,
                        }}
                      >
                        {result.category}
                      </span>
                      <span style={{ color: theme.textColor + "60" }}>{result.source}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleShareResult(result)}
                    className="p-2 rounded-full opacity-0 group-hover:opacity-100 transition-smooth"
                    style={{
                      backgroundColor: theme.accentColor + "20",
                      color: theme.accentColor,
                    }}
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Search History Modal */}
      {showHistory && (
        <SearchHistory
          theme={theme}
          onSelectSearch={(selectedQuery) => {
            setShowHistory(false)
            window.location.hash = `#search=${encodeURIComponent(selectedQuery)}`
            window.location.reload()
          }}
          onClose={() => setShowHistory(false)}
        />
      )}

      {/* Trending Searches Modal */}
      {showTrending && (
        <TrendingSearches
          theme={theme}
          onSelectSearch={(selectedQuery) => {
            setShowTrending(false)
            window.location.hash = `#search=${encodeURIComponent(selectedQuery)}`
            window.location.reload()
          }}
          onClose={() => setShowTrending(false)}
        />
      )}
    </div>
  )
}
