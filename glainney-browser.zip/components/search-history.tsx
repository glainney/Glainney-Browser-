"use client"

import { Trash2, Star, Pin, Clock } from "lucide-react"
import { useState, useEffect } from "react"

interface SearchHistoryItem {
  id: string
  query: string
  timestamp: number
  pinned: boolean
  favorite: boolean
}

interface SearchHistoryProps {
  theme: any
  onSelectSearch: (query: string) => void
  onClose: () => void
}

export default function SearchHistory({ theme, onSelectSearch, onClose }: SearchHistoryProps) {
  const [history, setHistory] = useState<SearchHistoryItem[]>([])
  const [activeTab, setActiveTab] = useState<"all" | "pinned" | "favorites">("all")

  useEffect(() => {
    const savedHistory = localStorage.getItem("glainney-search-history")
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory))
    }
  }, [])

  const saveHistory = (newHistory: SearchHistoryItem[]) => {
    setHistory(newHistory)
    localStorage.setItem("glainney-search-history", JSON.stringify(newHistory))
  }

  const togglePin = (id: string) => {
    const updated = history.map((item) => (item.id === id ? { ...item, pinned: !item.pinned } : item))
    saveHistory(updated)
  }

  const toggleFavorite = (id: string) => {
    const updated = history.map((item) => (item.id === id ? { ...item, favorite: !item.favorite } : item))
    saveHistory(updated)
  }

  const deleteItem = (id: string) => {
    const updated = history.filter((item) => item.id !== id)
    saveHistory(updated)
  }

  const filteredHistory = history.filter((item) => {
    if (activeTab === "pinned") return item.pinned
    if (activeTab === "favorites") return item.favorite
    return true
  })

  const sortedHistory = [...filteredHistory].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1
    if (!a.pinned && b.pinned) return 1
    return b.timestamp - a.timestamp
  })

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-3xl p-6 max-h-[80vh] overflow-y-auto"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
            Search History
          </h2>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b" style={{ borderColor: theme.accentColor + "20" }}>
          {(["all", "pinned", "favorites"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="px-4 py-2 font-medium transition-smooth capitalize"
              style={{
                color: activeTab === tab ? theme.accentColor : theme.textColor + "80",
                borderBottom: activeTab === tab ? `2px solid ${theme.accentColor}` : "none",
              }}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* History Items */}
        {sortedHistory.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-12 h-12 mx-auto mb-4 opacity-30" style={{ color: theme.textColor }} />
            <p style={{ color: theme.textColor + "80" }}>No search history yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {sortedHistory.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-3 p-3 rounded-xl hover:scale-102 transition-smooth group"
                style={{
                  backgroundColor: theme.highlightColor + "30",
                  border: `1px solid ${theme.accentColor}20`,
                }}
              >
                <button
                  onClick={() => togglePin(item.id)}
                  className="p-1 rounded-lg opacity-50 hover:opacity-100 transition-smooth"
                  style={{ color: theme.accentColor }}
                >
                  <Pin className={`w-4 h-4 ${item.pinned ? "fill-current" : ""}`} />
                </button>

                <button
                  onClick={() => onSelectSearch(item.query)}
                  className="flex-1 text-left font-medium hover:underline transition-smooth"
                  style={{ color: theme.textColor }}
                >
                  {item.query}
                </button>

                <span className="text-xs opacity-60" style={{ color: theme.textColor }}>
                  {new Date(item.timestamp).toLocaleDateString()}
                </span>

                <button
                  onClick={() => toggleFavorite(item.id)}
                  className="p-1 rounded-lg opacity-50 hover:opacity-100 transition-smooth"
                  style={{ color: theme.secondaryColor }}
                >
                  <Star className={`w-4 h-4 ${item.favorite ? "fill-current" : ""}`} />
                </button>

                <button
                  onClick={() => deleteItem(item.id)}
                  className="p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-smooth"
                  style={{ color: "#ff6b6b" }}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
