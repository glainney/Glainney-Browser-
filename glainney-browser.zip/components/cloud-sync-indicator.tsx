"use client"

import { useState, useEffect } from "react"
import { Cloud, CloudOff, Check } from "lucide-react"

interface CloudSyncIndicatorProps {
  theme: any
  isSynced: boolean
  isSyncing: boolean
}

export default function CloudSyncIndicator({ theme, isSynced, isSyncing }: CloudSyncIndicatorProps) {
  const [showMessage, setShowMessage] = useState(false)

  useEffect(() => {
    if (isSyncing) {
      setShowMessage(true)
    } else if (isSynced) {
      setShowMessage(true)
      const timer = setTimeout(() => setShowMessage(false), 2000)
      return () => clearTimeout(timer)
    }
  }, [isSyncing, isSynced])

  return (
    <div className="fixed bottom-6 right-6 flex items-center gap-2 transition-smooth">
      {showMessage && (
        <div
          className="px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2"
          style={{
            backgroundColor: theme.highlightColor + "40",
            color: theme.textColor,
          }}
        >
          {isSyncing ? (
            <>
              <Cloud className="w-4 h-4 animate-pulse" style={{ color: theme.accentColor }} />
              Syncing...
            </>
          ) : isSynced ? (
            <>
              <Check className="w-4 h-4" style={{ color: theme.accentColor }} />
              Synced to cloud
            </>
          ) : (
            <>
              <CloudOff className="w-4 h-4" style={{ color: "#ff6b6b" }} />
              Offline
            </>
          )}
        </div>
      )}
    </div>
  )
}
