"use client"

import { Clock, Music, X, Play, Pause } from "lucide-react"
import { useState, useEffect } from "react"

interface FocusModeProps {
  theme: any
  onClose: () => void
}

export default function FocusMode({ theme, onClose }: FocusModeProps) {
  const [minutes, setMinutes] = useState(25)
  const [seconds, setSeconds] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [totalTime, setTotalTime] = useState(25 * 60)
  const [musicEnabled, setMusicEnabled] = useState(true)

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isRunning && (minutes > 0 || seconds > 0)) {
      interval = setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1)
        } else if (minutes > 0) {
          setMinutes(minutes - 1)
          setSeconds(59)
        } else {
          setIsRunning(false)
          // Timer finished
        }
      }, 1000)
    }

    return () => clearInterval(interval)
  }, [isRunning, minutes, seconds])

  const progress = ((totalTime - (minutes * 60 + seconds)) / totalTime) * 100

  const handleStart = () => {
    setIsRunning(true)
  }

  const handlePause = () => {
    setIsRunning(false)
  }

  const handleReset = () => {
    setIsRunning(false)
    setMinutes(25)
    setSeconds(0)
    setTotalTime(25 * 60)
  }

  const handleSetTime = (mins: number) => {
    setIsRunning(false)
    setMinutes(mins)
    setSeconds(0)
    setTotalTime(mins * 60)
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.7)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl p-8"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6" style={{ color: theme.accentColor }} />
            <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
              Focus Mode
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-muted transition-smooth"
            style={{ color: theme.textColor }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Timer Display */}
        <div className="relative w-48 h-48 mx-auto mb-8">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r="90" fill="none" stroke={theme.highlightColor} strokeWidth="8" opacity="0.3" />
            <circle
              cx="100"
              cy="100"
              r="90"
              fill="none"
              stroke={theme.accentColor}
              strokeWidth="8"
              strokeDasharray={`${(progress / 100) * 565.48} 565.48`}
              strokeLinecap="round"
              style={{ transition: "stroke-dasharray 1s linear" }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-5xl font-bold" style={{ color: theme.textColor }}>
                {String(minutes).padStart(2, "0")}:{String(seconds).padStart(2, "0")}
              </div>
              <p className="text-sm mt-2" style={{ color: theme.textColor + "80" }}>
                Focus Time
              </p>
            </div>
          </div>
        </div>

        {/* Quick Time Buttons */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          {[5, 15, 25].map((time) => (
            <button
              key={time}
              onClick={() => handleSetTime(time)}
              className="py-2 rounded-lg font-medium transition-smooth hover:scale-105"
              style={{
                backgroundColor: minutes === time ? theme.accentColor : theme.highlightColor + "40",
                color: minutes === time ? "#fff" : theme.textColor,
              }}
            >
              {time}m
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="flex gap-3 mb-6">
          {!isRunning ? (
            <button
              onClick={handleStart}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-white transition-smooth hover:scale-105"
              style={{ backgroundColor: theme.accentColor }}
            >
              <Play className="w-4 h-4" />
              Start
            </button>
          ) : (
            <button
              onClick={handlePause}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-white transition-smooth hover:scale-105"
              style={{ backgroundColor: theme.accentColor }}
            >
              <Pause className="w-4 h-4" />
              Pause
            </button>
          )}
          <button
            onClick={handleReset}
            className="flex-1 py-3 rounded-xl font-semibold transition-smooth hover:scale-105"
            style={{ backgroundColor: theme.highlightColor + "40", color: theme.textColor }}
          >
            Reset
          </button>
        </div>

        {/* Music Toggle */}
        <label
          className="flex items-center gap-3 p-3 rounded-xl cursor-pointer"
          style={{ backgroundColor: theme.highlightColor + "40" }}
        >
          <Music className="w-5 h-5" style={{ color: theme.accentColor }} />
          <span className="flex-1 font-medium" style={{ color: theme.textColor }}>
            Ambient Music
          </span>
          <input
            type="checkbox"
            checked={musicEnabled}
            onChange={(e) => setMusicEnabled(e.target.checked)}
            className="w-4 h-4 rounded"
          />
        </label>

        <div className="mt-6 p-4 rounded-xl" style={{ backgroundColor: theme.highlightColor + "40" }}>
          <p className="text-sm" style={{ color: theme.textColor + "80" }}>
            Focus mode hides distractions and plays ambient music to help you concentrate. All your tabs and settings
            are preserved.
          </p>
        </div>
      </div>
    </div>
  )
}
