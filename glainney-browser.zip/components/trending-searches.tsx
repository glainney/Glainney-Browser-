"use client"

import { X, TrendingUp, Heart } from "lucide-react"
import { useState, useEffect } from "react"

interface TrendingSearch {
  query: string
  count: number
  trend: "up" | "down" | "stable"
  category: string
}

interface TrendingSearchesProps {
  theme: any
  onSelectSearch: (query: string) => void
  onClose: () => void
}

export default function TrendingSearches({ theme, onSelectSearch, onClose }: TrendingSearchesProps) {
  const [trendingSearches, setTrendingSearches] = useState<TrendingSearch[]>([])
  const [loading, setLoading] = useState(true)
  const [favorites, setFavorites] = useState<string[]>([])

  useEffect(() => {
    const savedFavorites = localStorage.getItem("glainney-trending-favorites") || "[]"
    setFavorites(JSON.parse(savedFavorites))

    // Simulate fetching trending searches
    const mockTrending: TrendingSearch[] = [
      {
        query: "how to learn web development",
        count: 1250,
        trend: "up",
        category: "Learning",
      },
      {
        query: "best productivity apps",
        count: 980,
        trend: "up",
        category: "Tools",
      },
      {
        query: "aesthetic design inspiration",
        count: 856,
        trend: "stable",
        category: "Design",
      },
      {
        query: "soft color palettes",
        count: 742,
        trend: "up",
        category: "Design",
      },
      {
        query: "meditation and mindfulness",
        count: 698,
        trend: "stable",
        category: "Wellness",
      },
      {
        query: "creative writing tips",
        count: 645,
        trend: "down",
        category: "Writing",
      },
      {
        query: "digital art tutorials",
        count: 612,
        trend: "up",
        category: "Art",
      },
      {
        query: "sustainable living",
        count: 589,
        trend: "stable",
        category: "Lifestyle",
      },
    ]

    setTimeout(() => {
      setTrendingSearches(mockTrending)
      setLoading(false)
    }, 300)
  }, [])

  const handleFavorite = (query: string) => {
    const updated = favorites.includes(query) ? favorites.filter((f) => f !== query) : [...favorites, query]
    setFavorites(updated)
    localStorage.setItem("glainney-trending-favorites", JSON.stringify(updated))
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up":
        return "📈"
      case "down":
        return "📉"
      default:
        return "➡️"
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div
        className="relative w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden"
        style={{ backgroundColor: theme.bgColor }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between p-6 border-b"
          style={{ borderColor: theme.accentColor + "20" }}
        >
          <div className="flex items-center gap-3">
            <TrendingUp style={{ color: theme.accentColor }} className="w-6 h-6" />
            <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
              Trending Searches
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/50 transition-smooth"
            style={{ color: theme.textColor }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="max-h-96 overflow-y-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div
                className="animate-spin rounded-full h-8 w-8"
                style={{
                  borderColor: theme.accentColor + "20",
                  borderTopColor: theme.accentColor,
                }}
              />
            </div>
          ) : (
            <div className="space-y-3">
              {trendingSearches.map((search, index) => (
                <div
                  key={index}
                  className="p-4 rounded-2xl flex items-center justify-between group hover:scale-102 transition-smooth cursor-pointer"
                  style={{
                    backgroundColor: theme.highlightColor + "40",
                    border: `1px solid ${theme.accentColor}20`,
                  }}
                  onClick={() => onSelectSearch(search.query)}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-lg">{getTrendIcon(search.trend)}</span>
                      <h3 className="font-semibold truncate group-hover:underline" style={{ color: theme.accentColor }}>
                        {search.query}
                      </h3>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <span
                        className="px-2 py-1 rounded-full"
                        style={{
                          backgroundColor: theme.accentColor + "20",
                          color: theme.accentColor,
                        }}
                      >
                        {search.category}
                      </span>
                      <span style={{ color: theme.textColor + "60" }}>{search.count.toLocaleString()} searches</span>
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      handleFavorite(search.query)
                    }}
                    className="p-2 rounded-full transition-smooth ml-2"
                    style={{
                      backgroundColor: favorites.includes(search.query) ? theme.secondaryColor + "40" : "transparent",
                      color: favorites.includes(search.query) ? theme.secondaryColor : theme.textColor + "60",
                    }}
                  >
                    <Heart
                      className="w-4 h-4"
                      fill={favorites.includes(search.query) ? theme.secondaryColor : "none"}
                    />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
