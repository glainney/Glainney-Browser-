"use client"

import { useState } from "react"
import { X, ChevronRight, Trash2, Eye, EyeOff } from "lucide-react"

interface SettingsPanelProps {
  theme: any
  user: any
  onClose: () => void
  onThemeChange?: (theme: any) => void
  onClearHistory?: () => void
}

type SettingsTab = "personalization" | "search" | "voice" | "privacy" | "account"

export default function SettingsPanel({ theme, user, onClose, onThemeChange, onClearHistory }: SettingsPanelProps) {
  const [activeTab, setActiveTab] = useState<SettingsTab>("personalization")
  const [safeSearch, setSafeSearch] = useState(true)
  const [minimalLayout, setMinimalLayout] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [voiceTone, setVoiceTone] = useState<"calm" | "friendly" | "formal">("calm")
  const [showPassword, setShowPassword] = useState(false)
  const [linkedDevices, setLinkedDevices] = useState([
    { id: 1, name: "Desktop", lastActive: "Now" },
    { id: 2, name: "Mobile", lastActive: "2 hours ago" },
  ])

  const tabs: Array<{ id: SettingsTab; label: string }> = [
    { id: "personalization", label: "Personalization" },
    { id: "search", label: "Search" },
    { id: "voice", label: "Voice" },
    { id: "privacy", label: "Privacy" },
    { id: "account", label: "Account" },
  ]

  const renderContent = () => {
    switch (activeTab) {
      case "personalization":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                Color Themes
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { name: "Sage Green", color: "#A8CBB7" },
                  { name: "Ocean Blue", color: "#7BA8D1" },
                  { name: "Sunset", color: "#F4A460" },
                ].map((t) => (
                  <button
                    key={t.name}
                    className="p-4 rounded-2xl transition-smooth hover:scale-105"
                    style={{ backgroundColor: t.color }}
                    title={t.name}
                  />
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                Wallpapers
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {["Floating Clouds", "Sparkles", "Gradient Flow"].map((wp) => (
                  <button
                    key={wp}
                    className="p-3 rounded-xl border-2 transition-smooth hover:scale-105"
                    style={{ borderColor: theme.accentColor, color: theme.textColor }}
                  >
                    {wp}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                Font Styles
              </h3>
              <div className="space-y-2">
                {["Poppins (Default)", "Handwritten", "Minimalist", "Serif"].map((font) => (
                  <button
                    key={font}
                    className="w-full p-3 rounded-xl text-left transition-smooth hover:bg-opacity-80"
                    style={{ backgroundColor: theme.highlightColor, color: theme.textColor }}
                  >
                    {font}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )

      case "search":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                AI Mode
              </h3>
              <div className="space-y-2">
                {["Concise", "Explainer", "Creative", "Source View"].map((mode) => (
                  <button
                    key={mode}
                    className="w-full p-3 rounded-xl text-left transition-smooth hover:bg-opacity-80 flex items-center justify-between"
                    style={{ backgroundColor: theme.highlightColor, color: theme.textColor }}
                  >
                    {mode}
                    <ChevronRight size={18} />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label
                className="flex items-center justify-between p-3 rounded-xl"
                style={{ backgroundColor: theme.highlightColor }}
              >
                <span style={{ color: theme.textColor }}>Safe Search</span>
                <input
                  type="checkbox"
                  checked={safeSearch}
                  onChange={(e) => setSafeSearch(e.target.checked)}
                  className="w-5 h-5 rounded cursor-pointer"
                />
              </label>
            </div>

            <div>
              <label
                className="flex items-center justify-between p-3 rounded-xl"
                style={{ backgroundColor: theme.highlightColor }}
              >
                <span style={{ color: theme.textColor }}>Minimal Layout</span>
                <input
                  type="checkbox"
                  checked={minimalLayout}
                  onChange={(e) => setMinimalLayout(e.target.checked)}
                  className="w-5 h-5 rounded cursor-pointer"
                />
              </label>
            </div>
          </div>
        )

      case "voice":
        return (
          <div className="space-y-6">
            <div>
              <label
                className="flex items-center justify-between p-3 rounded-xl"
                style={{ backgroundColor: theme.highlightColor }}
              >
                <span style={{ color: theme.textColor }}>Enable Microphone</span>
                <input
                  type="checkbox"
                  checked={voiceEnabled}
                  onChange={(e) => setVoiceEnabled(e.target.checked)}
                  className="w-5 h-5 rounded cursor-pointer"
                />
              </label>
            </div>

            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                AI Voice Tone
              </h3>
              <div className="space-y-2">
                {(["calm", "friendly", "formal"] as const).map((tone) => (
                  <button
                    key={tone}
                    onClick={() => setVoiceTone(tone)}
                    className="w-full p-3 rounded-xl text-left transition-smooth capitalize"
                    style={{
                      backgroundColor: voiceTone === tone ? theme.accentColor : theme.highlightColor,
                      color: voiceTone === tone ? "#fff" : theme.textColor,
                    }}
                  >
                    {tone}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )

      case "privacy":
        return (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                History Management
              </h3>
              <button
                onClick={onClearHistory}
                className="w-full p-3 rounded-xl flex items-center gap-2 transition-smooth hover:scale-105"
                style={{ backgroundColor: "#ff6b6b", color: "#fff" }}
              >
                <Trash2 size={18} />
                Clear All History
              </button>
            </div>

            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                Search Visibility
              </h3>
              <div className="space-y-2">
                {["Public", "Private", "Friends Only"].map((visibility) => (
                  <button
                    key={visibility}
                    className="w-full p-3 rounded-xl text-left transition-smooth hover:bg-opacity-80"
                    style={{ backgroundColor: theme.highlightColor, color: theme.textColor }}
                  >
                    {visibility}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label
                className="flex items-center justify-between p-3 rounded-xl"
                style={{ backgroundColor: theme.highlightColor }}
              >
                <span style={{ color: theme.textColor }}>Save Search History</span>
                <input type="checkbox" defaultChecked className="w-5 h-5 rounded cursor-pointer" />
              </label>
            </div>
          </div>
        )

      case "account":
        return (
          <div className="space-y-6">
            {user && (
              <div>
                <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                  Account Info
                </h3>
                <div className="space-y-3">
                  <div className="p-3 rounded-xl" style={{ backgroundColor: theme.highlightColor }}>
                    <p className="text-sm" style={{ color: theme.textColor }}>
                      Email
                    </p>
                    <p className="font-semibold" style={{ color: theme.accentColor }}>
                      {user.email}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl" style={{ backgroundColor: theme.highlightColor }}>
                    <p className="text-sm" style={{ color: theme.textColor }}>
                      Username
                    </p>
                    <input
                      type="text"
                      defaultValue={user.username || "User"}
                      className="w-full bg-transparent font-semibold outline-none"
                      style={{ color: theme.accentColor }}
                    />
                  </div>
                </div>
              </div>
            )}

            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                Password
              </h3>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="w-full p-3 rounded-xl outline-none"
                  style={{ backgroundColor: theme.highlightColor, color: theme.textColor }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: theme.accentColor }}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3" style={{ color: theme.textColor }}>
                Linked Devices
              </h3>
              <div className="space-y-2">
                {linkedDevices.map((device) => (
                  <div key={device.id} className="p-3 rounded-xl" style={{ backgroundColor: theme.highlightColor }}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold" style={{ color: theme.textColor }}>
                          {device.name}
                        </p>
                        <p className="text-sm" style={{ color: theme.textColor }}>
                          Last active: {device.lastActive}
                        </p>
                      </div>
                      <button className="text-red-500 hover:scale-110 transition-smooth">
                        <X size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
    >
      <div
        className="w-full max-w-2xl max-h-[80vh] rounded-3xl flex flex-col shadow-2xl animate-fade-in-scale overflow-hidden"
        style={{ backgroundColor: theme.bgColor }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: theme.highlightColor }}>
          <h2 className="text-2xl font-bold" style={{ color: theme.accentColor }}>
            Settings
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-opacity-80 rounded-full transition-smooth"
            style={{ backgroundColor: theme.highlightColor }}
          >
            <X size={20} style={{ color: theme.textColor }} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 px-6 py-4 border-b overflow-x-auto" style={{ borderColor: theme.highlightColor }}>
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="px-4 py-2 rounded-full font-medium transition-smooth whitespace-nowrap"
              style={{
                backgroundColor: activeTab === tab.id ? theme.accentColor : theme.highlightColor,
                color: activeTab === tab.id ? "#fff" : theme.textColor,
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">{renderContent()}</div>

        {/* Footer */}
        <div className="flex gap-3 p-6 border-t" style={{ borderColor: theme.highlightColor }}>
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 rounded-full font-medium transition-smooth"
            style={{ backgroundColor: theme.highlightColor, color: theme.textColor }}
          >
            Cancel
          </button>
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 rounded-full font-medium transition-smooth text-white"
            style={{ backgroundColor: theme.accentColor }}
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  )
}
