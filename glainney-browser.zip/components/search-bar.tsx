"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Search, Mic, MessageCircle } from "lucide-react"

interface SearchBarProps {
  theme: any
  onSearch: (query: string) => void
  onAIToggle?: (enabled: boolean) => void
  onVoiceSearch?: (query: string) => void
}

export default function SearchBar({ theme, onSearch, onAIToggle, onVoiceSearch }: SearchBarProps) {
  const [query, setQuery] = useState("")
  const [isFocused, setIsFocused] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [useAI, setUseAI] = useState(false)
  const recognitionRef = useRef<any>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = false
        recognitionRef.current.interimResults = true

        recognitionRef.current.onresult = (event: any) => {
          let transcript = ""
          for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript
          }
          setQuery(transcript)
        }

        recognitionRef.current.onerror = (event: any) => {
          console.error("[v0] Speech recognition error:", event.error)
          setIsListening(false)
        }

        recognitionRef.current.onend = () => {
          setIsListening(false)
        }
      }
    }
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      if (useAI && onAIToggle) {
        onAIToggle(true)
      }
      onSearch(query)
      setQuery("")
    }
  }

  const handleVoiceSearch = () => {
    if (!recognitionRef.current) return

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
    } else {
      recognitionRef.current.start()
      setIsListening(true)
    }
  }

  const handleAIToggle = () => {
    setUseAI(!useAI)
    if (onAIToggle) {
      onAIToggle(!useAI)
    }
  }

  return (
    <form onSubmit={handleSearch} className="w-full max-w-3xl mb-12">
      <div
        className={`relative transition-smooth ${isFocused ? "scale-105" : "scale-100"}`}
        style={{
          borderRadius: theme.searchBarRadius,
        }}
      >
        <div
          className={`flex items-center gap-3 px-6 py-4 rounded-full transition-smooth ${
            isFocused && theme.searchBarGlow ? "animate-pulse-glow" : ""
          }`}
          style={{
            backgroundColor: theme.searchBarColor,
            borderRadius: theme.searchBarRadius,
            boxShadow: isFocused ? `0 0 30px ${theme.accentColor}40` : "0 8px 24px rgba(0, 0, 0, 0.08)",
          }}
        >
          <Search className="w-5 h-5 flex-shrink-0 transition-smooth" style={{ color: theme.accentColor }} />

          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            placeholder={useAI ? "Ask Glainney AI..." : "Search the web..."}
            className="flex-1 bg-transparent outline-none font-medium transition-smooth"
            style={{
              color: theme.textColor,
              fontSize: query.length > 50 ? "0.9rem" : "1rem",
            }}
          />

          <button
            type="button"
            onClick={handleVoiceSearch}
            className="p-2 rounded-full transition-smooth hover:scale-110"
            style={{
              backgroundColor: isListening ? theme.secondaryColor : "transparent",
              color: isListening ? "#fff" : theme.accentColor,
            }}
            title="Voice search"
          >
            <Mic size={20} />
          </button>

          <button
            type="button"
            onClick={handleAIToggle}
            className="p-2 rounded-full transition-smooth hover:scale-110"
            style={{
              backgroundColor: useAI ? theme.accentColor : "transparent",
              color: useAI ? "#fff" : theme.accentColor,
            }}
            title="Toggle AI mode"
          >
            <MessageCircle size={20} />
          </button>
        </div>
      </div>

      {useAI && (
        <div className="mt-3 flex items-center gap-2 px-2 animate-fade-in-scale">
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: theme.accentColor }} />
          <span className="text-sm font-medium" style={{ color: theme.accentColor }}>
            Chat with Glainney AI
          </span>
        </div>
      )}

      {isListening && (
        <div className="mt-3 flex items-center gap-2 px-2 animate-fade-in-scale">
          <div className="flex gap-1">
            <div className="w-1 h-3 rounded-full animate-bounce" style={{ backgroundColor: theme.secondaryColor }} />
            <div
              className="w-1 h-3 rounded-full animate-bounce"
              style={{ backgroundColor: theme.secondaryColor, animationDelay: "0.1s" }}
            />
            <div
              className="w-1 h-3 rounded-full animate-bounce"
              style={{ backgroundColor: theme.secondaryColor, animationDelay: "0.2s" }}
            />
          </div>
          <span className="text-sm font-medium" style={{ color: theme.secondaryColor }}>
            Listening...
          </span>
        </div>
      )}
    </form>
  )
}
