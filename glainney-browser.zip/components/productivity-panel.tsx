"use client"

import { BookmarkPlus, FileText, Zap } from "lucide-react"
import { useState } from "react"

interface ProductivityPanelProps {
  theme: any
  onClose: () => void
}

export default function ProductivityPanel({ theme, onClose }: ProductivityPanelProps) {
  const [bookmarks, setBookmarks] = useState<any[]>([])
  const [notes, setNotes] = useState<any[]>([])
  const [newNote, setNewNote] = useState("")
  const [newBookmark, setNewBookmark] = useState({ title: "", url: "" })

  const addBookmark = () => {
    if (newBookmark.title && newBookmark.url) {
      setBookmarks([...bookmarks, { ...newBookmark, id: Date.now() }])
      setNewBookmark({ title: "", url: "" })
    }
  }

  const addNote = () => {
    if (newNote.trim()) {
      setNotes([...notes, { id: Date.now(), text: newNote, createdAt: new Date() }])
      setNewNote("")
    }
  }

  const deleteBookmark = (id: number) => {
    setBookmarks(bookmarks.filter((b) => b.id !== id))
  }

  const deleteNote = (id: number) => {
    setNotes(notes.filter((n) => n.id !== id))
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-3xl p-8 max-h-[80vh] overflow-y-auto"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6" style={{ color: theme.accentColor }} />
            <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
              Productivity Tools
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        {/* Bookmarks Section */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <BookmarkPlus className="w-5 h-5" style={{ color: theme.accentColor }} />
            <h3 className="text-lg font-bold" style={{ color: theme.textColor }}>
              Quick Bookmarks
            </h3>
          </div>

          <div className="space-y-3 mb-4">
            <input
              type="text"
              value={newBookmark.title}
              onChange={(e) => setNewBookmark({ ...newBookmark, title: e.target.value })}
              placeholder="Bookmark title"
              className="w-full px-4 py-2 rounded-xl bg-card border border-border text-foreground placeholder-muted-foreground"
            />
            <input
              type="url"
              value={newBookmark.url}
              onChange={(e) => setNewBookmark({ ...newBookmark, url: e.target.value })}
              placeholder="https://example.com"
              className="w-full px-4 py-2 rounded-xl bg-card border border-border text-foreground placeholder-muted-foreground"
            />
            <button
              onClick={addBookmark}
              className="w-full py-2 rounded-xl font-semibold text-white transition-smooth hover:scale-105"
              style={{ backgroundColor: theme.accentColor }}
            >
              Add Bookmark
            </button>
          </div>

          {bookmarks.length > 0 && (
            <div className="space-y-2">
              {bookmarks.map((bookmark) => (
                <div
                  key={bookmark.id}
                  className="flex items-center justify-between p-3 rounded-xl"
                  style={{ backgroundColor: theme.highlightColor + "40" }}
                >
                  <a
                    href={bookmark.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 font-medium hover:underline"
                    style={{ color: theme.accentColor }}
                  >
                    {bookmark.title}
                  </a>
                  <button
                    onClick={() => deleteBookmark(bookmark.id)}
                    className="text-sm px-2 py-1 rounded opacity-50 hover:opacity-100 transition-smooth"
                    style={{ color: "#ff6b6b" }}
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Notes Section */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-5 h-5" style={{ color: theme.accentColor }} />
            <h3 className="text-lg font-bold" style={{ color: theme.textColor }}>
              Quick Notes
            </h3>
          </div>

          <div className="space-y-3 mb-4">
            <textarea
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="Write a quick note..."
              className="w-full px-4 py-2 rounded-xl bg-card border border-border text-foreground placeholder-muted-foreground resize-none h-24"
            />
            <button
              onClick={addNote}
              className="w-full py-2 rounded-xl font-semibold text-white transition-smooth hover:scale-105"
              style={{ backgroundColor: theme.accentColor }}
            >
              Save Note
            </button>
          </div>

          {notes.length > 0 && (
            <div className="space-y-2">
              {notes.map((note) => (
                <div
                  key={note.id}
                  className="p-3 rounded-xl flex items-start justify-between"
                  style={{ backgroundColor: theme.highlightColor + "40" }}
                >
                  <div className="flex-1">
                    <p style={{ color: theme.textColor }}>{note.text}</p>
                    <p className="text-xs mt-1" style={{ color: theme.textColor + "60" }}>
                      {note.createdAt.toLocaleTimeString()}
                    </p>
                  </div>
                  <button
                    onClick={() => deleteNote(note.id)}
                    className="text-sm px-2 py-1 rounded opacity-50 hover:opacity-100 transition-smooth"
                    style={{ color: "#ff6b6b" }}
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
