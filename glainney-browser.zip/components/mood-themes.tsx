"use client"

import type React from "react"

import { Sparkles, Heart, Moon, Zap } from "lucide-react"
import { useState } from "react"

interface MoodTheme {
  id: string
  name: string
  icon: React.ReactNode
  colors: {
    bgColor: string
    accentColor: string
    secondaryColor: string
    highlightColor: string
    textColor: string
  }
  music: string
  description: string
}

interface MoodThemesProps {
  theme: any
  onApplyMood: (moodTheme: MoodTheme) => void
  onClose: () => void
}

const MOOD_THEMES: MoodTheme[] = [
  {
    id: "calm",
    name: "Calm",
    icon: <Moon className="w-6 h-6" />,
    colors: {
      bgColor: "#F5F3F0",
      accentColor: "#7BA89F",
      secondaryColor: "#D4C5E2",
      highlightColor: "#E8DFD5",
      textColor: "#4A4A4A",
    },
    music: "ambient-calm",
    description: "Peaceful and serene atmosphere for relaxation",
  },
  {
    id: "romantic",
    name: "Romantic",
    icon: <Heart className="w-6 h-6" />,
    colors: {
      bgColor: "#FDF8F6",
      accentColor: "#E8A8C8",
      secondaryColor: "#F5D4E6",
      highlightColor: "#FFE8F0",
      textColor: "#5A3A4A",
    },
    music: "ambient-romantic",
    description: "Warm and intimate vibes with soft pastels",
  },
  {
    id: "dreamy",
    name: "Dreamy",
    icon: <Sparkles className="w-6 h-6" />,
    colors: {
      bgColor: "#F0E8F8",
      accentColor: "#B8A8D8",
      secondaryColor: "#E8D4F5",
      highlightColor: "#D8C8E8",
      textColor: "#4A3A5A",
    },
    music: "ambient-dreamy",
    description: "Magical and whimsical with ethereal colors",
  },
  {
    id: "focus",
    name: "Focus",
    icon: <Zap className="w-6 h-6" />,
    colors: {
      bgColor: "#FAFAF8",
      accentColor: "#6B9B8F",
      secondaryColor: "#C8D8D0",
      highlightColor: "#E8F0E8",
      textColor: "#2A2A2A",
    },
    music: "ambient-focus",
    description: "Clean and energizing for productivity",
  },
]

export default function MoodThemes({ theme, onApplyMood, onClose }: MoodThemesProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null)

  const handleApplyMood = (moodTheme: MoodTheme) => {
    setSelectedMood(moodTheme.id)
    onApplyMood(moodTheme)
    setTimeout(() => onClose(), 300)
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-3xl p-8 max-h-[80vh] overflow-y-auto"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold" style={{ color: theme.textColor }}>
            Choose Your Mood
          </h2>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        <p className="mb-8" style={{ color: theme.textColor + "80" }}>
          Select a mood to change your browser's atmosphere, colors, and ambient music
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {MOOD_THEMES.map((moodTheme) => (
            <button
              key={moodTheme.id}
              onClick={() => handleApplyMood(moodTheme)}
              className="p-6 rounded-2xl transition-smooth hover:scale-105 group relative overflow-hidden"
              style={{
                backgroundColor: moodTheme.colors.bgColor,
                border:
                  selectedMood === moodTheme.id
                    ? `3px solid ${moodTheme.colors.accentColor}`
                    : `2px solid ${moodTheme.colors.accentColor}40`,
              }}
            >
              {/* Background gradient effect */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-smooth"
                style={{ backgroundColor: moodTheme.colors.accentColor }}
              />

              <div className="relative z-10">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-smooth"
                  style={{ backgroundColor: moodTheme.colors.accentColor, color: "#fff" }}
                >
                  {moodTheme.icon}
                </div>

                <h3 className="text-xl font-bold mb-2" style={{ color: moodTheme.colors.textColor }}>
                  {moodTheme.name}
                </h3>

                <p className="text-sm" style={{ color: moodTheme.colors.textColor + "80" }}>
                  {moodTheme.description}
                </p>

                {/* Color preview */}
                <div className="flex gap-2 mt-4">
                  {[moodTheme.colors.accentColor, moodTheme.colors.secondaryColor, moodTheme.colors.highlightColor].map(
                    (color, idx) => (
                      <div
                        key={idx}
                        className="w-6 h-6 rounded-full border-2"
                        style={{ backgroundColor: color, borderColor: moodTheme.colors.textColor + "40" }}
                      />
                    ),
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8 p-4 rounded-xl" style={{ backgroundColor: theme.highlightColor + "40" }}>
          <p className="text-sm" style={{ color: theme.textColor + "80" }}>
            Tip: Each mood comes with curated ambient music. Enable music in the header to enjoy the full experience.
          </p>
        </div>
      </div>
    </div>
  )
}
