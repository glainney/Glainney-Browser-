"use client"

import { Sparkles } from "lucide-react"
import { useState, useEffect } from "react"

interface DailyInspirationProps {
  theme: any
}

const INSPIRATIONAL_QUOTES = [
  "Every moment is a fresh beginning.",
  "You are capable of amazing things.",
  "Progress, not perfection.",
  "Your potential is limitless.",
  "Today is full of possibilities.",
  "Be kind to yourself.",
  "You've got this!",
  "Small steps lead to big changes.",
  "Your creativity is your superpower.",
  "Embrace the journey.",
]

export default function DailyInspiration({ theme }: DailyInspirationProps) {
  const [quote, setQuote] = useState("")

  useEffect(() => {
    const today = new Date().toDateString()
    const savedQuote = localStorage.getItem("glainney-daily-quote")
    const savedDate = localStorage.getItem("glainney-quote-date")

    if (savedDate === today && savedQuote) {
      setQuote(savedQuote)
    } else {
      const newQuote = INSPIRATIONAL_QUOTES[Math.floor(Math.random() * INSPIRATIONAL_QUOTES.length)]
      setQuote(newQuote)
      localStorage.setItem("glainney-daily-quote", newQuote)
      localStorage.setItem("glainney-quote-date", today)
    }
  }, [])

  return (
    <div
      className="max-w-md mx-auto mb-8 p-6 rounded-2xl flex items-center gap-4 animate-fade-in-scale"
      style={{
        backgroundColor: theme.highlightColor + "40",
        border: `2px solid ${theme.accentColor}20`,
      }}
    >
      <Sparkles className="w-6 h-6 flex-shrink-0" style={{ color: theme.accentColor }} />
      <div>
        <p className="text-sm font-medium" style={{ color: theme.textColor + "80" }}>
          Today's Inspiration
        </p>
        <p className="text-lg font-semibold mt-1" style={{ color: theme.textColor }}>
          {quote}
        </p>
      </div>
    </div>
  )
}
