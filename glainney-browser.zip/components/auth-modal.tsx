"use client"

import type React from "react"
import { useState } from "react"
import { Mail, Lock, User, ArrowRight, AlertCircle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface AuthModalProps {
  theme: any
  onClose: () => void
  onAuthSuccess: (user: any) => void
}

export default function AuthModal({ theme, onClose, onAuthSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<"login" | "signup">("login")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [username, setUsername] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState("")
  const supabase = createClient()

  const validateEmail = (email: string) => {
    return email.endsWith("@glainney.com")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")
    setLoading(true)

    try {
      if (!email.trim()) {
        setError("Email is required")
        setLoading(false)
        return
      }

      if (!validateEmail(email)) {
        setError("Email must be in format: username@glainney.com")
        setLoading(false)
        return
      }

      if (!password || password.length < 6) {
        setError("Password must be at least 6 characters")
        setLoading(false)
        return
      }

      if (mode === "signup") {
        if (!username.trim()) {
          setError("Username is required")
          setLoading(false)
          return
        }

        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}`,
            data: {
              username,
            },
          },
        })

        if (signUpError) {
          setError(signUpError.message || "Sign up failed")
          setLoading(false)
          return
        }

        if (!data.user) {
          setError("Sign up failed: No user returned")
          setLoading(false)
          return
        }

        const { error: profileError } = await supabase.from("profiles").insert([
          {
            id: data.user.id,
            username,
            email,
            created_at: new Date().toISOString(),
          },
        ])

        if (profileError) {
          console.error("[v0] Profile creation error:", profileError)
          // Don't fail the signup if profile creation fails
        }

        setSuccess("Account created successfully! You can now sign in.")
        setEmail("")
        setPassword("")
        setUsername("")

        // Auto-switch to login after 2 seconds
        setTimeout(() => {
          setMode("login")
          setSuccess("")
        }, 2000)
      } else {
        const { data, error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        })

        if (signInError) {
          setError(signInError.message || "Sign in failed")
          setLoading(false)
          return
        }

        if (!data.user) {
          setError("Sign in failed: No user returned")
          setLoading(false)
          return
        }

        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", data.user.id)
          .single()

        if (profileError && profileError.code !== "PGRST116") {
          console.error("[v0] Profile fetch error:", profileError)
        }

        const userData = {
          id: data.user.id,
          email: data.user.email,
          username: profile?.username || email.split("@")[0],
          createdAt: profile?.created_at || new Date().toISOString(),
        }

        localStorage.setItem("glainney-user", JSON.stringify(userData))
        localStorage.setItem("glainney-auth-token", data.session?.access_token || "")

        onAuthSuccess(userData)
        onClose()
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An error occurred. Please try again."
      console.error("[v0] Auth error:", err)
      setError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl p-8 max-h-[90vh] overflow-y-auto"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2" style={{ color: theme.textColor }}>
            {mode === "login" ? "Welcome Back" : "Join Glainney"}
          </h2>
          <p style={{ color: theme.textColor + "80" }}>
            {mode === "login"
              ? "Sign in to sync your themes and bookmarks"
              : "Create your Glainney account to sync across devices"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "signup" && (
            <div>
              <label className="block text-sm font-medium mb-2" style={{ color: theme.textColor }}>
                Username
              </label>
              <div
                className="flex items-center gap-3 px-4 py-3 rounded-xl"
                style={{ backgroundColor: theme.highlightColor + "40" }}
              >
                <User className="w-5 h-5" style={{ color: theme.accentColor }} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Your name"
                  className="flex-1 bg-transparent outline-none"
                  style={{ color: theme.textColor }}
                  disabled={loading}
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: theme.textColor }}>
              Email
            </label>
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-xl"
              style={{ backgroundColor: theme.highlightColor + "40" }}
            >
              <Mail className="w-5 h-5" style={{ color: theme.accentColor }} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="username@glainney.com"
                className="flex-1 bg-transparent outline-none"
                style={{ color: theme.textColor }}
                disabled={loading}
              />
            </div>
            <p className="text-xs mt-1" style={{ color: theme.textColor + "60" }}>
              Must use @glainney.com domain
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: theme.textColor }}>
              Password
            </label>
            <div
              className="flex items-center gap-3 px-4 py-3 rounded-xl"
              style={{ backgroundColor: theme.highlightColor + "40" }}
            >
              <Lock className="w-5 h-5" style={{ color: theme.accentColor }} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="flex-1 bg-transparent outline-none"
                style={{ color: theme.textColor }}
                disabled={loading}
              />
            </div>
          </div>

          {error && (
            <div
              className="p-3 rounded-xl flex items-center gap-2"
              style={{ backgroundColor: "#ff6b6b20", color: "#ff6b6b" }}
            >
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {success && (
            <div
              className="p-3 rounded-xl flex items-center gap-2"
              style={{ backgroundColor: theme.accentColor + "20", color: theme.accentColor }}
            >
              <span className="text-sm">{success}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition-smooth hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ backgroundColor: theme.accentColor }}
          >
            {loading ? "Loading..." : mode === "login" ? "Sign In" : "Create Account"}
            {!loading && <ArrowRight className="w-4 h-4" />}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p style={{ color: theme.textColor + "80" }}>
            {mode === "login" ? "Don't have an account?" : "Already have an account?"}
            <button
              onClick={() => {
                setMode(mode === "login" ? "signup" : "login")
                setError("")
                setSuccess("")
              }}
              className="ml-2 font-semibold hover:underline"
              style={{ color: theme.accentColor }}
              disabled={loading}
            >
              {mode === "login" ? "Sign up" : "Sign in"}
            </button>
          </p>
        </div>
      </div>
    </div>
  )
}
