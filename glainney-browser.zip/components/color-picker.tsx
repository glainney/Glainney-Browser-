"use client"

interface ColorPickerProps {
  value: string
  onChange: (value: string) => void
}

export default function ColorPicker({ value, onChange }: ColorPickerProps) {
  return (
    <div className="flex items-center gap-3">
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-12 h-12 rounded-2xl cursor-pointer border-2 border-border hover:border-primary transition-colors"
      />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="flex-1 px-4 py-2 border border-border rounded-2xl bg-card text-foreground font-mono text-sm"
      />
    </div>
  )
}
