"use client"

import { X, Plus, Folder, Calendar, Grid } from "lucide-react"
import { useState, useEffect } from "react"

interface Tab {
  id: string
  title: string
  url: string
  category: string
  createdAt: number
  favicon?: string
}

interface TabManagerProps {
  theme: any
  onSelectTab: (tab: Tab) => void
  onClose: () => void
}

export default function TabManager({ theme, onSelectTab, onClose }: TabManagerProps) {
  const [tabs, setTabs] = useState<Tab[]>([])
  const [viewMode, setViewMode] = useState<"grid" | "list" | "category">("grid")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  useEffect(() => {
    const savedTabs = localStorage.getItem("glainney-tabs")
    if (savedTabs) {
      setTabs(JSON.parse(savedTabs))
    }
  }, [])

  const saveTabs = (newTabs: Tab[]) => {
    setTabs(newTabs)
    localStorage.setItem("glainney-tabs", JSON.stringify(newTabs))
  }

  const closeTab = (id: string) => {
    const updated = tabs.filter((tab) => tab.id !== id)
    saveTabs(updated)
  }

  const categories = Array.from(new Set(tabs.map((tab) => tab.category)))
  const filteredTabs = selectedCategory === "all" ? tabs : tabs.filter((tab) => tab.category === selectedCategory)

  const sortedTabs = [...filteredTabs].sort((a, b) => b.createdAt - a.createdAt)

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl rounded-3xl p-6 max-h-[80vh] overflow-y-auto"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
            Open Tabs ({tabs.length})
          </h2>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        {/* View Mode Selector */}
        <div className="flex gap-2 mb-6">
          {(["grid", "list", "category"] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className="px-4 py-2 rounded-lg font-medium transition-smooth capitalize flex items-center gap-2"
              style={{
                backgroundColor: viewMode === mode ? theme.accentColor : theme.highlightColor + "40",
                color: viewMode === mode ? "#fff" : theme.textColor,
              }}
            >
              {mode === "grid" && <Grid className="w-4 h-4" />}
              {mode === "category" && <Folder className="w-4 h-4" />}
              {mode === "list" && <Calendar className="w-4 h-4" />}
              {mode}
            </button>
          ))}
        </div>

        {/* Category Filter */}
        {viewMode === "category" && categories.length > 0 && (
          <div className="flex gap-2 mb-6 flex-wrap">
            <button
              onClick={() => setSelectedCategory("all")}
              className="px-3 py-1 rounded-full text-sm font-medium transition-smooth"
              style={{
                backgroundColor: selectedCategory === "all" ? theme.accentColor : theme.highlightColor + "40",
                color: selectedCategory === "all" ? "#fff" : theme.textColor,
              }}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className="px-3 py-1 rounded-full text-sm font-medium transition-smooth"
                style={{
                  backgroundColor: selectedCategory === cat ? theme.accentColor : theme.highlightColor + "40",
                  color: selectedCategory === cat ? "#fff" : theme.textColor,
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Tabs Display */}
        {tabs.length === 0 ? (
          <div className="text-center py-12">
            <Plus className="w-12 h-12 mx-auto mb-4 opacity-30" style={{ color: theme.textColor }} />
            <p style={{ color: theme.textColor + "80" }}>No open tabs yet</p>
          </div>
        ) : viewMode === "grid" ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {sortedTabs.map((tab) => (
              <div
                key={tab.id}
                className="p-4 rounded-2xl cursor-pointer transition-smooth hover:scale-105 group relative"
                style={{
                  backgroundColor: theme.highlightColor + "40",
                  border: `1px solid ${theme.accentColor}20`,
                }}
                onClick={() => onSelectTab(tab)}
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    closeTab(tab.id)
                  }}
                  className="absolute top-2 right-2 p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-smooth"
                  style={{ backgroundColor: "#ff6b6b", color: "#fff" }}
                >
                  <X className="w-4 h-4" />
                </button>
                <h3 className="font-semibold text-sm mb-2 line-clamp-2" style={{ color: theme.textColor }}>
                  {tab.title}
                </h3>
                <p className="text-xs truncate" style={{ color: theme.textColor + "60" }}>
                  {tab.url}
                </p>
                <p className="text-xs mt-2" style={{ color: theme.textColor + "80" }}>
                  {tab.category}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {sortedTabs.map((tab) => (
              <div
                key={tab.id}
                className="flex items-center gap-3 p-3 rounded-xl hover:scale-102 transition-smooth group cursor-pointer"
                style={{
                  backgroundColor: theme.highlightColor + "30",
                  border: `1px solid ${theme.accentColor}20`,
                }}
                onClick={() => onSelectTab(tab)}
              >
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium" style={{ color: theme.textColor }}>
                    {tab.title}
                  </h3>
                  <p className="text-xs truncate" style={{ color: theme.textColor + "60" }}>
                    {tab.url}
                  </p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full" style={{ backgroundColor: theme.accentColor + "20" }}>
                  {tab.category}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    closeTab(tab.id)
                  }}
                  className="p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-smooth"
                  style={{ color: "#ff6b6b" }}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
