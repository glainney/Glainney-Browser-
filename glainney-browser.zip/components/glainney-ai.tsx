"use client"

import { useState, useRef, useEffect } from "react"
import { generateAIResponse, type AIMode, type AIResponse } from "@/lib/ai/glainney-ai"
import { Mic, Send, X, Copy, Share2 } from "lucide-react"

interface GlainneyChatMessage {
  id: string
  type: "user" | "assistant"
  content: string
  mode?: AIMode
  sources?: AIResponse["sources"]
  followUpQuestions?: string[]
  timestamp: Date
}

interface GlainneyChatProps {
  theme: any
  onClose: () => void
  initialQuery?: string
}

export default function GlainneyChatAssistant({ theme, onClose, initialQuery }: GlainneyChatProps) {
  const [messages, setMessages] = useState<GlainneyChatMessage[]>([])
  const [input, setInput] = useState(initialQuery || "")
  const [loading, setLoading] = useState(false)
  const [mode, setMode] = useState<AIMode>("concise")
  const [isListening, setIsListening] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = false
        recognitionRef.current.interimResults = true

        recognitionRef.current.onresult = (event: any) => {
          let transcript = ""
          for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript
          }
          setInput(transcript)
        }

        recognitionRef.current.onerror = (event: any) => {
          console.error("[v0] Speech recognition error:", event.error)
          setIsListening(false)
        }

        recognitionRef.current.onend = () => {
          setIsListening(false)
        }
      }
    }
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async () => {
    if (!input.trim()) return

    const userMessage: GlainneyChatMessage = {
      id: Date.now().toString(),
      type: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setLoading(true)

    try {
      const response = await generateAIResponse(input, mode)

      const assistantMessage: GlainneyChatMessage = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: response.answer,
        mode: response.mode,
        sources: response.sources,
        followUpQuestions: response.followUpQuestions,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("[v0] Error generating response:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleVoiceSearch = () => {
    if (!recognitionRef.current) return

    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
    } else {
      recognitionRef.current.start()
      setIsListening(true)
    }
  }

  const handleFollowUp = (question: string) => {
    setInput(question)
  }

  const handleCopyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const handleShareMessage = (content: string) => {
    if (navigator.share) {
      navigator.share({
        title: "Glainney AI Response",
        text: content,
      })
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
    >
      <div
        className="w-full max-w-2xl h-[600px] rounded-3xl flex flex-col shadow-2xl animate-fade-in-scale"
        style={{ backgroundColor: theme.bgColor, border: `2px solid ${theme.accentColor}` }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: theme.highlightColor }}>
          <div>
            <h2 className="text-2xl font-bold" style={{ color: theme.accentColor }}>
              Glainney AI
            </h2>
            <p className="text-sm" style={{ color: theme.textColor }}>
              Your intelligent assistant
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-opacity-80 rounded-full transition-smooth"
            style={{ backgroundColor: theme.highlightColor }}
          >
            <X size={20} style={{ color: theme.textColor }} />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="flex gap-2 px-6 py-4 border-b overflow-x-auto" style={{ borderColor: theme.highlightColor }}>
          {(["concise", "explainer", "creative", "source"] as AIMode[]).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className="px-4 py-2 rounded-full font-medium transition-smooth whitespace-nowrap capitalize"
              style={{
                backgroundColor: mode === m ? theme.accentColor : theme.highlightColor,
                color: mode === m ? "#fff" : theme.textColor,
              }}
            >
              {m}
            </button>
          ))}
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="text-5xl mb-4 animate-float" style={{ color: theme.accentColor }}>
                  ✨
                </div>
                <p className="text-lg font-medium" style={{ color: theme.textColor }}>
                  Ask me anything!
                </p>
                <p className="text-sm mt-2" style={{ color: theme.textColor }}>
                  I'm here to help with questions, explanations, and creative ideas.
                </p>
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className="max-w-xs lg:max-w-md rounded-2xl p-4 animate-fade-in-scale"
                  style={{
                    backgroundColor: msg.type === "user" ? theme.accentColor : theme.highlightColor,
                    color: msg.type === "user" ? "#fff" : theme.textColor,
                  }}
                >
                  <p className="text-sm">{msg.content}</p>

                  {msg.type === "assistant" && (
                    <div className="mt-3 space-y-2">
                      {msg.sources && (
                        <div className="text-xs space-y-1">
                          <p className="font-semibold">Sources:</p>
                          {msg.sources.map((source, idx) => (
                            <div key={idx} className="opacity-80">
                              <p className="font-medium">{source.title}</p>
                              <p className="text-xs">{source.summary}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-2 mt-2">
                        <button
                          onClick={() => handleCopyMessage(msg.content)}
                          className="p-1 hover:opacity-80 transition-smooth"
                          title="Copy"
                        >
                          <Copy size={16} />
                        </button>
                        <button
                          onClick={() => handleShareMessage(msg.content)}
                          className="p-1 hover:opacity-80 transition-smooth"
                          title="Share"
                        >
                          <Share2 size={16} />
                        </button>
                      </div>

                      {msg.followUpQuestions && msg.followUpQuestions.length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-xs font-semibold">Follow-up questions:</p>
                          {msg.followUpQuestions.map((q, idx) => (
                            <button
                              key={idx}
                              onClick={() => handleFollowUp(q)}
                              className="block text-xs hover:opacity-80 transition-smooth text-left"
                            >
                              • {q}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="flex justify-start">
              <div className="rounded-2xl p-4" style={{ backgroundColor: theme.highlightColor }}>
                <div className="flex gap-2">
                  <div className="w-2 h-2 rounded-full animate-bounce" style={{ backgroundColor: theme.accentColor }} />
                  <div
                    className="w-2 h-2 rounded-full animate-bounce"
                    style={{ backgroundColor: theme.accentColor, animationDelay: "0.1s" }}
                  />
                  <div
                    className="w-2 h-2 rounded-full animate-bounce"
                    style={{ backgroundColor: theme.accentColor, animationDelay: "0.2s" }}
                  />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-6 border-t" style={{ borderColor: theme.highlightColor }}>
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder="Ask Glainney AI..."
              className="flex-1 px-4 py-3 rounded-full border-2 focus:outline-none transition-smooth"
              style={{
                borderColor: theme.accentColor,
                backgroundColor: theme.bgColor,
                color: theme.textColor,
              }}
              disabled={loading}
            />
            <button
              onClick={handleVoiceSearch}
              className="p-3 rounded-full transition-smooth hover:scale-110"
              style={{
                backgroundColor: isListening ? theme.secondaryColor : theme.highlightColor,
                color: theme.textColor,
              }}
              title="Voice search"
            >
              <Mic size={20} />
            </button>
            <button
              onClick={handleSendMessage}
              disabled={loading || !input.trim()}
              className="p-3 rounded-full transition-smooth hover:scale-110 disabled:opacity-50"
              style={{ backgroundColor: theme.accentColor, color: "#fff" }}
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
