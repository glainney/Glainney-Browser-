"use client"

import { Send, Sparkles, Mic, X } from "lucide-react"
import { useState, useRef, useEffect } from "react"

interface Message {
  id: string
  text: string
  sender: "user" | "assistant"
  timestamp: Date
}

interface AIAssistantProps {
  theme: any
  onClose: () => void
}

const SAMPLE_RESPONSES = [
  "I can help you find information, answer questions, or suggest cute wallpapers for your browser!",
  "Try asking me about productivity tips, study techniques, or aesthetic design ideas.",
  "I'm here to make your browsing experience more enjoyable and productive.",
  "Would you like me to suggest a wallpaper based on your current mood?",
  "I can help you organize your bookmarks or create a study schedule.",
]

export default function AIAssistant({ theme, onClose }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm Glainney's AI Assistant. How can I help you today?",
      sender: "assistant",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isListening, setIsListening] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    if (typeof window !== "undefined") {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.onstart = () => setIsListening(true)
        recognitionRef.current.onend = () => setIsListening(false)
        recognitionRef.current.onresult = (event: any) => {
          const transcript = Array.from(event.results)
            .map((result: any) => result[0].transcript)
            .join("")
          setInput(transcript)
        }
      }
    }
  }, [])

  const handleSendMessage = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages([...messages, userMessage])
    setInput("")

    // Simulate AI response
    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: SAMPLE_RESPONSES[Math.floor(Math.random() * SAMPLE_RESPONSES.length)],
        sender: "assistant",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])
    }, 500)
  }

  const handleVoiceSearch = () => {
    if (recognitionRef.current) {
      if (isListening) {
        recognitionRef.current.stop()
      } else {
        recognitionRef.current.start()
      }
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md h-[600px] rounded-3xl flex flex-col"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between p-6 border-b"
          style={{ borderColor: theme.accentColor + "20" }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{ backgroundColor: theme.accentColor }}
            >
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-bold" style={{ color: theme.textColor }}>
              Glainney AI
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-muted transition-smooth"
            style={{ color: theme.textColor }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className="max-w-xs px-4 py-3 rounded-2xl"
                style={{
                  backgroundColor: message.sender === "user" ? theme.accentColor : theme.highlightColor + "40",
                  color: message.sender === "user" ? "#fff" : theme.textColor,
                }}
              >
                <p className="text-sm">{message.text}</p>
                <p
                  className="text-xs mt-1"
                  style={{
                    color: message.sender === "user" ? "rgba(255,255,255,0.7)" : theme.textColor + "60",
                  }}
                >
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-6 border-t" style={{ borderColor: theme.accentColor + "20" }}>
          <div className="flex gap-2 mb-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder="Ask me anything..."
              className="flex-1 px-4 py-2 rounded-xl bg-card border border-border text-foreground placeholder-muted-foreground"
            />
            <button
              onClick={handleSendMessage}
              className="p-2 rounded-xl transition-smooth hover:scale-110"
              style={{ backgroundColor: theme.accentColor, color: "#fff" }}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <button
            onClick={handleVoiceSearch}
            className={`w-full flex items-center justify-center gap-2 py-2 rounded-xl font-medium transition-smooth ${
              isListening ? "scale-105" : "hover:scale-105"
            }`}
            style={{
              backgroundColor: isListening ? theme.secondaryColor : theme.highlightColor + "40",
              color: isListening ? "#fff" : theme.textColor,
            }}
          >
            <Mic className="w-4 h-4" />
            {isListening ? "Listening..." : "Voice Input"}
          </button>
        </div>
      </div>
    </div>
  )
}
