"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ChevronDown } from "lucide-react"

const QUOTES = [
  "Take a moment to breathe.",
  "You are doing great.",
  "Embrace the calm.",
  "Create something beautiful today.",
  "Be kind to yourself.",
  "Every moment is a fresh start.",
  "Your creativity matters.",
  "Find joy in the little things.",
  "Progress over perfection.",
  "You've got this.",
]

export default function TimeWidget() {
  const [time, setTime] = useState("")
  const [date, setDate] = useState("")
  const [quote, setQuote] = useState("")
  const [isExpanded, setIsExpanded] = useState(false)
  const [notes, setNotes] = useState("")

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      setTime(now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }))
      setDate(now.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }))
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    // Set random quote
    setQuote(QUOTES[Math.floor(Math.random() * QUOTES.length)])

    // Load saved notes
    const savedNotes = localStorage.getItem("glainney-notes")
    if (savedNotes) {
      setNotes(savedNotes)
    }

    return () => clearInterval(interval)
  }, [])

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newNotes = e.target.value
    setNotes(newNotes)
    localStorage.setItem("glainney-notes", newNotes)
  }

  return (
    <div className="text-center mb-16 animate-slide-in">
      <div className="text-5xl font-bold text-foreground mb-2 animate-fade-in-scale">{time}</div>
      <div className="text-lg text-muted-foreground mb-6">{date}</div>
      <div className="text-sm italic text-primary max-w-md mx-auto mb-6">{quote}</div>

      {/* Expandable Notes Section */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-center gap-2 mx-auto px-4 py-2 rounded-full bg-muted hover:bg-primary/20 transition-smooth text-sm font-medium"
      >
        <span>Quick Notes</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
      </button>

      {isExpanded && (
        <div className="mt-4 animate-fade-in-scale">
          <textarea
            value={notes}
            onChange={handleNotesChange}
            placeholder="Add your thoughts here..."
            className="w-full max-w-md mx-auto p-3 rounded-2xl bg-card border border-border text-foreground placeholder-muted-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary transition-smooth"
            rows={3}
          />
        </div>
      )}
    </div>
  )
}
