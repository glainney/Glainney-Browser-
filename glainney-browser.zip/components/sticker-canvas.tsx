"use client"

import type React from "react"

import { useRef, useState } from "react"
import { X } from "lucide-react"

interface Sticker {
  id: number
  emoji: string
  x: number
  y: number
  size: number
}

interface StickerCanvasProps {
  stickers: Sticker[]
  onRemoveSticker: (id: number) => void
  onUpdateSticker?: (id: number, x: number, y: number) => void
}

export default function StickerCanvas({ stickers, onRemoveSticker, onUpdateSticker }: StickerCanvasProps) {
  const [draggingId, setDraggingId] = useState<number | null>(null)
  const [offset, setOffset] = useState({ x: 0, y: 0 })
  const containerRef = useRef<HTMLDivElement>(null)

  const handleMouseDown = (e: React.MouseEvent, stickerId: number) => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect()
      const sticker = stickers.find((s) => s.id === stickerId)
      if (sticker) {
        setDraggingId(stickerId)
        const stickerPixelX = (sticker.x / 100) * rect.width
        const stickerPixelY = (sticker.y / 100) * rect.height
        setOffset({
          x: e.clientX - rect.left - stickerPixelX,
          y: e.clientY - rect.top - stickerPixelY,
        })
      }
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggingId !== null && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect()
      const newPixelX = e.clientX - rect.left - offset.x
      const newPixelY = e.clientY - rect.top - offset.y

      // Constrain to container bounds
      const constrainedX = Math.max(0, Math.min(newPixelX, rect.width - 50))
      const constrainedY = Math.max(0, Math.min(newPixelY, rect.height - 50))

      // Convert back to percentage
      const newX = (constrainedX / rect.width) * 100
      const newY = (constrainedY / rect.height) * 100

      if (onUpdateSticker) {
        onUpdateSticker(draggingId, newX, newY)
      }
    }
  }

  const handleMouseUp = () => {
    setDraggingId(null)
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {stickers.map((sticker) => (
        <div
          key={sticker.id}
          className="absolute pointer-events-auto group cursor-move transition-transform hover:scale-125"
          style={{
            left: `${sticker.x}%`,
            top: `${sticker.y}%`,
            transform: "translate(-50%, -50%)",
          }}
          onMouseDown={(e) => handleMouseDown(e, sticker.id)}
        >
          <div className="relative">
            <span className="text-4xl select-none animate-float">{sticker.emoji}</span>
            <button
              onClick={() => onRemoveSticker(sticker.id)}
              className="absolute -top-2 -right-2 p-1 bg-destructive text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}
