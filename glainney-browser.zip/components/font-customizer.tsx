"use client"

import { Type } from "lucide-react"

interface FontCustomizerProps {
  theme: any
  onSelectFont: (fontFamily: string) => void
  onClose: () => void
  currentFont: string
}

const FONT_OPTIONS = [
  { id: "poppins", name: "Poppins", family: "Poppins, sans-serif", description: "Clean and modern" },
  {
    id: "playfair",
    name: "Playfair Display",
    family: "'Playfair Display', serif",
    description: "Elegant and sophisticated",
  },
  { id: "inter", name: "Inter", family: "Inter, sans-serif", description: "Minimalist and clear" },
  {
    id: "caveat",
    name: "Caveat",
    family: "'Caveat', cursive",
    description: "Handwritten and playful",
  },
  {
    id: "fredoka",
    name: "Fredoka",
    family: "'Fredoka', sans-serif",
    description: "Rounded and friendly",
  },
]

export default function FontCustomizer({ theme, onSelectFont, onClose, currentFont }: FontCustomizerProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-3xl p-8"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Type className="w-6 h-6" style={{ color: theme.accentColor }} />
            <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
              Font Customizer
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        <div className="space-y-3">
          {FONT_OPTIONS.map((font) => (
            <button
              key={font.id}
              onClick={() => {
                onSelectFont(font.family)
                onClose()
              }}
              className="w-full p-4 rounded-2xl transition-smooth hover:scale-102 group text-left"
              style={{
                backgroundColor: currentFont === font.family ? theme.accentColor + "30" : theme.highlightColor + "40",
                border:
                  currentFont === font.family ? `2px solid ${theme.accentColor}` : `2px solid ${theme.accentColor}20`,
              }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-lg" style={{ color: theme.textColor, fontFamily: font.family }}>
                    {font.name}
                  </h3>
                  <p className="text-sm" style={{ color: theme.textColor + "80", fontFamily: font.family }}>
                    {font.description}
                  </p>
                </div>
                {currentFont === font.family && (
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center text-white text-sm font-bold"
                    style={{ backgroundColor: theme.accentColor }}
                  >
                    ✓
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        <div className="mt-6 p-4 rounded-xl" style={{ backgroundColor: theme.highlightColor + "40" }}>
          <p className="text-sm" style={{ color: theme.textColor + "80" }}>
            Choose a font that matches your aesthetic. Your selection will be applied throughout the browser.
          </p>
        </div>
      </div>
    </div>
  )
}
