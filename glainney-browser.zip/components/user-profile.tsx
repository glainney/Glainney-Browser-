"use client"

import { LogOut, Settings, Cloud } from "lucide-react"
import { useState } from "react"

interface UserProfileProps {
  user: any
  theme: any
  onLogout: () => void
  onClose: () => void
}

export default function UserProfile({ user, theme, onLogout, onClose }: UserProfileProps) {
  const [syncStatus, setSyncStatus] = useState("synced")

  const handleSync = () => {
    setSyncStatus("syncing")
    setTimeout(() => setSyncStatus("synced"), 1500)
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl p-8"
        style={{ backgroundColor: theme.bgColor }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: theme.textColor }}>
            Profile
          </h2>
          <button
            onClick={onClose}
            className="text-2xl font-bold opacity-50 hover:opacity-100 transition-smooth"
            style={{ color: theme.textColor }}
          >
            ×
          </button>
        </div>

        <div className="mb-6 p-4 rounded-2xl" style={{ backgroundColor: theme.highlightColor + "40" }}>
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
              style={{ backgroundColor: theme.accentColor }}
            >
              {user.username.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="font-semibold" style={{ color: theme.textColor }}>
                {user.username}
              </h3>
              <p className="text-sm" style={{ color: theme.textColor + "80" }}>
                {user.email}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3 mb-6">
          <button
            onClick={handleSync}
            className="w-full flex items-center gap-3 p-3 rounded-xl transition-smooth hover:scale-102"
            style={{
              backgroundColor: theme.highlightColor + "40",
              color: theme.textColor,
            }}
          >
            <Cloud className="w-5 h-5" style={{ color: theme.accentColor }} />
            <div className="flex-1 text-left">
              <p className="font-medium">Sync Data</p>
              <p className="text-xs" style={{ color: theme.textColor + "60" }}>
                {syncStatus === "syncing" ? "Syncing..." : "Last synced just now"}
              </p>
            </div>
          </button>

          <button
            className="w-full flex items-center gap-3 p-3 rounded-xl transition-smooth hover:scale-102"
            style={{
              backgroundColor: theme.highlightColor + "40",
              color: theme.textColor,
            }}
          >
            <Settings className="w-5 h-5" style={{ color: theme.accentColor }} />
            <div className="flex-1 text-left">
              <p className="font-medium">Account Settings</p>
              <p className="text-xs" style={{ color: theme.textColor + "60" }}>
                Manage your preferences
              </p>
            </div>
          </button>
        </div>

        <button
          onClick={() => {
            onLogout()
            onClose()
          }}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-white transition-smooth hover:scale-105"
          style={{ backgroundColor: "#ff6b6b" }}
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  )
}
