-- Create saved themes table
create table if not exists public.saved_themes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  bg_color text default '#FDFBF8',
  accent_color text default '#A8CBB7',
  secondary_color text default '#F8C8DC',
  highlight_color text default '#CFE8E0',
  text_color text default '#333333',
  bg_image text,
  bg_video text,
  search_bar_color text default '#FFFFFF',
  search_bar_radius text default '1.2rem',
  search_bar_glow boolean default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.saved_themes enable row level security;

-- RLS Policies for saved_themes
create policy "saved_themes_select_own"
  on public.saved_themes for select
  using (auth.uid() = user_id);

create policy "saved_themes_insert_own"
  on public.saved_themes for insert
  with check (auth.uid() = user_id);

create policy "saved_themes_update_own"
  on public.saved_themes for update
  using (auth.uid() = user_id);

create policy "saved_themes_delete_own"
  on public.saved_themes for delete
  using (auth.uid() = user_id);

create index if not exists saved_themes_user_id_idx on public.saved_themes(user_id);
