-- Create search history table
create table if not exists public.search_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  query text not null,
  is_pinned boolean default false,
  is_favorite boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.search_history enable row level security;

-- RLS Policies for search_history
create policy "search_history_select_own"
  on public.search_history for select
  using (auth.uid() = user_id);

create policy "search_history_insert_own"
  on public.search_history for insert
  with check (auth.uid() = user_id);

create policy "search_history_update_own"
  on public.search_history for update
  using (auth.uid() = user_id);

create policy "search_history_delete_own"
  on public.search_history for delete
  using (auth.uid() = user_id);

-- Create index for faster queries
create index if not exists search_history_user_id_idx on public.search_history(user_id);
create index if not exists search_history_created_at_idx on public.search_history(created_at desc);
