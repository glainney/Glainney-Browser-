-- Create tabs table for tab management
create table if not exists public.tabs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  url text not null,
  category text default 'General',
  is_active boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.tabs enable row level security;

-- RLS Policies for tabs
create policy "tabs_select_own"
  on public.tabs for select
  using (auth.uid() = user_id);

create policy "tabs_insert_own"
  on public.tabs for insert
  with check (auth.uid() = user_id);

create policy "tabs_update_own"
  on public.tabs for update
  using (auth.uid() = user_id);

create policy "tabs_delete_own"
  on public.tabs for delete
  using (auth.uid() = user_id);

create index if not exists tabs_user_id_idx on public.tabs(user_id);
